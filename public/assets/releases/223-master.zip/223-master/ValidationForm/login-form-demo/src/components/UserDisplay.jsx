import { useContext } from "react";
import { AuthContext } from "../contexts/AuthContext";

function UserDisplay() {
  // ==========================================
  // CONTEXT: User-Daten holen
  // ==========================================
  const { user, isAuthenticated, logout } = useContext(AuthContext);
 
  if (!isAuthenticated) {
    return (
      <div className="container">
        <p>❌ Nicht eingeloggt</p>
      </div>
    );
  }

  // Fall 2: User ist eingeloggt
  return (
    <div className="container">
      <h2>👤 Eingeloggter User</h2>

      <div
        style={{ background: "#f0f0f0", padding: "15px", borderRadius: "8px" }}
      >
        <p>
          <strong>ID:</strong> {user.id}
        </p>
        <p>
          <strong>Username:</strong> {user.username}
        </p>
        <p>
          <strong>Email:</strong> {user.email}
        </p>
        <p>
          <strong>Rolle:</strong>
          <span
            style={{
              background: user.role === "ADMIN" ? "#ff4444" : "#4444ff",
              color: "white",
              padding: "3px 10px",
              borderRadius: "4px",
              marginLeft: "10px",
            }}
          >
            {user.role}
          </span>
        </p>
      </div>

      <button
        onClick={logout}
        style={{ background: "#dc3545", marginTop: "15px", fontFamily:"monospace" }}
      >
        🚪 Abmelden
      </button>
    </div>
  );
}

export default UserDisplay;
