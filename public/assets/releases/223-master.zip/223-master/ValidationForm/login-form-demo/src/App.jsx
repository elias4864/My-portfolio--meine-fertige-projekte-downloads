import LoginForm from "./components/LoginForm";
import Login from "./pages/Login"; // ← NEU

function App() {
  return (
    <div>
      <h1>🔐 Auth Context Demo</h1>
      <p>Hier bauen wir unseren AuthContext!</p>
      <LoginForm />
    </div>
  );
}

export default App;
