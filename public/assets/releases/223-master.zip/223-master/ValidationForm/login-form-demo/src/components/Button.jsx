// Button.jsx
import React from "react";

const Button = ({ text, onAnswerClick, disabled, className }) => {
  return (
    <button
      type="submit" // Wichtig für Formulare!
      onClick={onAnswerClick}
      disabled={disabled}
      className={`btn ${className}`} // Kombiniert Basis-Klasse mit deiner Prop
    >
      {text}
    </button>
  );
};

export default Button;
