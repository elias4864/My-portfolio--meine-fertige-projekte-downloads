import "./App.css";
import LoginForm from "./LoginForm";

function App() {
  return (
    <div>
      <h1>🔐 Login Form Demo</h1>
      <p>Hier bauen wir ein Login mit Validation!</p>
      <LoginForm />
    </div>
  );
}

export default App;
