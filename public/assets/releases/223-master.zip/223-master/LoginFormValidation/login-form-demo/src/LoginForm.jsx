import { useState } from "react";
import Button from "./Button"; // Falls Button.jsx im selben Ordner liegt

function LoginForm() {
  // ==========================================
  // STATE: Formular-Daten
  // ==========================================
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // ==========================================
  // STATE: Fehler-Messages
  // ==========================================
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  // ==========================================
  // STATE: Submit Status
  // ==========================================
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // ==========================================
  // VALIDATION FUNKTIONEN
  // ==========================================

  /**
   * Email validieren
   * Regeln: Nicht leer, muss @ enthalten
   */
  const validateEmail = (value) => {
    // Regel 1: Darf nicht leer sein
    if (!value.trim()) {
      setEmailError("Email ist erforderlich");
      return false;
    }

    // Regel 2: Muss @ enthalten
    if (!value.includes("@")) {
      setEmailError("Email muss @ enthalten");
      return false;
    }

    // Regel 3: Muss . nach @ enthalten
    const atIndex = value.indexOf("@");
    const dotAfterAt = value.indexOf(".", atIndex);
    if (dotAfterAt === -1) {
      setEmailError("Email muss einen Punkt nach dem @ enthalten");
      return false;
    }

    // Regel 4: Muss 2-3 Zeichen nach dem letzten Punkt haben
    const charsAfterDot = value.length - dotAfterAt - 1;
    if (charsAfterDot < 2 || charsAfterDot > 3) {
      setEmailError("Email muss 2-3 Zeichcn mach dem Punkt haben");

      return false;
    }

    // Alles ok!
    setEmailError("");
    return true;
  };

  /**
   * Password validieren
   * Regeln: Nicht leer, mindestens 6 Zeichen
   */
  const validatePassword = (value) => {
    // Regel 1: Darf nicht leer sein
    if (!value) {
      setPasswordError("Passwort ist erforderlich");
      return false;
    }

    // Regel 2: Mindestens 6 Zeichen
    if (value.length < 6) {
      setPasswordError("Passwort muss mindestens 6 Zeichen haben");
      return false;
    }

    // Alles ok!
    setPasswordError("");
    return true;
  };

  // ==========================================
  // HANDLER: onChange (während Tippen)
  // ==========================================

  const handleEmailChange = (e) => {
    const value = e.target.value;
    setEmail(value);
    // Sofort validieren während Tippen
    validateEmail(value);
  };

  const handlePasswordChange = (e) => {
    const value = e.target.value;
    setPassword(value);
    // Sofort validieren während Tippen
    validatePassword(value);
  };

  // ==========================================
  // HANDLER: Submit
  // ==========================================

  const handleSubmit = (e) => {
    e.preventDefault();

    // Alle Felder validieren
    const emailOk = validateEmail(email);
    const passwordOk = validatePassword(password);

    // Wenn Fehler vorhanden, abbrechen
    if (!emailOk || !passwordOk) {
      console.log("❌ Validation fehlgeschlagen");
      return;
    }

    // Alles ok! Simuliere Submit
    setIsSubmitting(true);

    // Simuliere API Call (1 Sekunde)
    setTimeout(() => {
      console.log("✅ Login erfolgreich!");
      console.log("Email:", email);
      console.log("Password:", password);

      setIsSubmitting(false);
      setSubmitSuccess(true);

      // Form zurücksetzen nach 2 Sekunden
      setTimeout(() => {
        setEmail("");
        setPassword("");
        setEmailError("");
        setPasswordError("");
        setSubmitSuccess(false);
      }, 2000);
    }, 1000);
  };

  // ==========================================
  // HELPER: Input CSS Klasse bestimmen
  // ==========================================

  const getInputClassName = (hasError, hasValue) => {
    if (!hasValue) return ""; // Noch nichts eingegeben
    if (hasError) return "invalid"; // Fehler -> rot
    return "valid"; // Ok -> grün
  };

  // ==========================================
  // RENDER
  // ==========================================

  return (
    <div className="login-form">
      <h2>🔐 Login</h2>

      <form onSubmit={handleSubmit}>
        {/* EMAIL FELD */}
        <div className="form-group">
          <label htmlFor="email">
            Email
            <span className="required"> *</span>
          </label>

          <input
            id="email"
            type="email"
            value={email}
            onChange={handleEmailChange}
            className={getInputClassName(emailError, email)}
            placeholder="deine@email.ch"
            disabled={isSubmitting}
          />

       

          {/* Error Message */}
          {emailError && <div className="error-message">❌ {emailError}</div>}

          {/* Success Message */}
          {!emailError && email && (
            <div className="success-message"> Email gültig</div>
          )}
        </div>

        {/* PASSWORD FELD */}
        <div className="form-group">
          <label htmlFor="password">
            Passwort
            <span className="required"> *</span>
          </label>

          <input
            id="password"
            type="password"
            value={password}
            onChange={handlePasswordChange}
            className={getInputClassName(passwordError, password)}
            placeholder="Mindestens 6 Zeichen"
            disabled={isSubmitting}
            required="Bitte ein Password eingeben"
          />



          {/* Error Message */}
          {passwordError && (
            <div className="error-message">❌ {passwordError}</div>
          )}

          {/* Success Message */}
          {!passwordError && password && (
            <div className="success-message">✅ Passwort gültig</div>
          )}
        </div>

        {/* SUBMIT BUTTON */}
        <button className="login"
          type="submit"
          disabled={isSubmitting || emailError || passwordError}
        >
          {isSubmitting ? "🔄 Logging in..." : "Login"}
        </button>
      </form>

      {/* SUCCESS MESSAGE */}
      {submitSuccess && (
        <div className="success-box">
          🎉 Login erfolgreich! Form wird zurückgesetzt...
        </div>
      )}
    </div>
  );
}

export default LoginForm;
