import React from "react";

// Wir nehmen die Props entgegen, die du in LoginForm benutzt:
// text, onAnswerClick, disabled, className
const Button = ({ text, onAnswerClick, disabled, className }) => {
  return (
    <button
      // type="submit" sorgt dafür, dass das Formular abgeschickt wird
      type="submit"
      // Hier wird deine handleSubmit-Funktion verknüpft
      onClick={onAnswerClick}
      disabled={disabled}
      // Hier werden die CSS-Klassen (z.B. "submit-button") angewendet
      className={`custom-button ${className}`}
    >
      {text}
    </button>
  );
};

export default Button;
