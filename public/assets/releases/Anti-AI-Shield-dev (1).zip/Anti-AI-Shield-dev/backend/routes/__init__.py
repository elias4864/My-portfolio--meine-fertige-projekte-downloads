"""Routen für die Anti-AI DocShield API."""
