"""Stellt den Upload-Endpunkt zum Verarbeiten und Herunterladen von Dateien bereit."""

from io import BytesIO
from urllib.parse import quote

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import StreamingResponse

from backend.config import MAX_FILE_SIZE_BYTES, MAX_FILE_SIZE_MB
from backend.services.document_router import process_document

router = APIRouter()


@router.post("/document/process")
async def process_document_route(
    file: UploadFile = File(...),
    stufe: str = Form(...),
) -> StreamingResponse:
    """Prüft Upload und Schutzstufe und liefert das Ergebnis als Download zurück."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="Bitte eine Datei auswählen.")

    file_bytes = await file.read(MAX_FILE_SIZE_BYTES + 1)
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Die Datei ist leer.")

    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        raise HTTPException(
            status_code=400,
            detail=f"Die Datei überschreitet die maximale Dateigröße von {MAX_FILE_SIZE_MB} MB.",
        )

    try:
        result_bytes, output_filename = process_document(
            file.filename,
            file_bytes,
            stufe,
        )
        ascii_filename = output_filename.encode("ascii", "ignore").decode("ascii")
        if not ascii_filename:
            ascii_filename = "download"
        encoded_filename = quote(output_filename)
        headers = {
            "Content-Disposition": f'attachment; filename="{ascii_filename}"; filename*=UTF-8\'\'{encoded_filename}',
            "Access-Control-Expose-Headers": "Content-Disposition",
        }

    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except Exception as error:
        raise HTTPException(status_code=500, detail=f"Fehler bei der Verarbeitung: {str(error)}") from error

    return StreamingResponse(
        BytesIO(result_bytes),
        media_type="application/octet-stream",
        headers=headers,
    )
