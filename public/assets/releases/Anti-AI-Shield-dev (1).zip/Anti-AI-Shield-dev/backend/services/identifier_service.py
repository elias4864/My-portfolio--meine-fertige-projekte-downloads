import random


# Die Kennung hat 10 Zeichen: KLS-XXXXXX
# Die sechs Zeichen bestehen aus zufälligen Buchstaben (A-Z) oder Zahlen (0-9).
vergebene_kennungen=set()
def create_identifier():
    # TODO (NEU): Bei dauerhaft eindeutigen Kennungen Vergabe speichern und Kollisionen prüfen.
    kennungsn = "KLS-"
    zeichen = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    zufall = random.choices(zeichen, k=6)
    erkennung = kennungsn + "".join(zufall)
    # Kollisionsprüfung: Prüfen, ob die Kennung bereits existiert
    if erkennung not in vergebene_kennungen:
        vergebene_kennungen.add(erkennung)
        return erkennung

    #Ausgabe Testen
    print(create_identifier())
    print(create_identifier())
    print(create_identifier())


    while True:
        # Solange neue Kennungen erzeugen bis eine noch nicht vergeben oder gefunden wurde
        zufall = random.choices(zeichen, k=6)
        kennung = zeichen + "".join(zufall)



# Prüft das Format der Kennung, nicht eine kryptografische Prüfziffer.
def is_valid_identifier(identifier):
    if not isinstance(identifier, str):
        return False

    # Drei Bedingungen: richtiger Anfang, insgesamt 10 Zeichen,
    # und die letzten sechs Zeichen sind Buchstaben oder Zahlen.
    if (
        identifier.startswith("KLS-")
        and len(identifier) == 10
        and all(
            zeichen in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            for zeichen in identifier[4:]
        )
    ):
        return True
    else:
        return False


# Nur beim direkten Start ausführen, nicht beim Import in andere Dateien.
if __name__ == "__main__":
    for _ in range(5):
        identifier = create_identifier()
    print("Generrierte Kennung:", identifier,"ist gültig",is_valid_identifier(identifier))
    print("Alle bisher vergebenen Kennungen",sorted(vergebene_kennungen))
    print("Anzahl vergebener Kennungen",len(vergebene_kennungen))