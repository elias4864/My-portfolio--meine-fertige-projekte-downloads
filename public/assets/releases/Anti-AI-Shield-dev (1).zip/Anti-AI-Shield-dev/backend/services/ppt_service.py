import io
from typing import Tuple
from backend.services import powerpoint_service


def process(inhalt: bytes, stufe: str, original_filename: str = "presentation.pptx") -> Tuple[bytes, str]:
    """
    Verarbeitet PowerPoint-Dateien für den Anti-AI-Shield.
    Gibt die verarbeiteten Bytes und den neuen Dateinamen zurück.
    """
    try:
        verarbeiteter_inhalt, _ = powerpoint_service.process(inhalt, stufe)
    except Exception as e:
        raise RuntimeError(f"Fehler bei der PowerPoint-Verarbeitung (Anti-AI-Shield): {str(e)}") from e

    # Dateinamen korrekt übernehmen und mit 'protected_' versehen
    if "." in original_filename:
        name, ext = original_filename.rsplit(".", 1)
        neuer_dateiname = f"protected_{name}.{ext}"
    else:
        neuer_dateiname = "protected_presentation.pptx"

    return verarbeiteter_inhalt, neuer_dateiname
