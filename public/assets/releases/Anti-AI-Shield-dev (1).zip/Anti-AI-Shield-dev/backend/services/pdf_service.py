"""Verarbeitet und schützt PDF-Dateien im Arbeitsspeicher."""

import io
from pypdf import PdfReader, PdfWriter

# Einheitliche Schutzstufen-Konfiguration (kompatibel mit Word & PPTX)
SCHUTZSTUFEN = {
    "high": {
        "aliases": {"hard", "hoch", "high", "3"},
        "text": "Anti-AI-Shield [HIGH]: Scraping & automatisches Auslesen strengstens untersagt.",
        "level": 3,
    },
    "medium": {
        "aliases": {"medium", "mittel", "2"},
        "text": "Anti-AI-Shield [MEDIUM]: Urheberrechtlich geschützter Inhalt.",
        "level": 2,
    },
    "basic": {
        "aliases": {"basic", "easy", "niedrig", "1"},
        "text": "Anti-AI-Shield [BASIC]: Hinweis aktiv.",
        "level": 1,
    },
}


"""
Schutzstufe wird definiert
"""

def get_schutzstufe_config(stufe: str) -> dict:
    """Normalisiert die Eingabe und liefert die einheitliche Schutzstufen-Konfiguration."""
    stufe_clean = str(stufe).strip().lower()
    for config in SCHUTZSTUFEN.values():
        if stufe_clean in config["aliases"]:
            return config
    return SCHUTZSTUFEN["basic"]


def process(inhalt: bytes, stufe: str) -> tuple[bytes, str]:
    """Zentrale Schnittstelle für die PDF-Verarbeitung, welcher die Datei direkt  an den  process_pdf-Service weiterleitet)."""
    return process_pdf(inhalt, stufe)


def process_pdf(inhalt: bytes, stufe: str) -> tuple[bytes, str]:
    """Kopiert PDF-Seiten, setzt Stufen-Metadaten, wendet je nach Schutzstufe

    Einschränkungen an und gibt Bytes sowie Dateinamen zurück.
    """
    try:
        # 1. PDF aus Bytes im Arbeitsspeicher öffnen (ohne temporäre Datei auf Festplatte)
        input_stream = io.BytesIO(inhalt)
        reader = PdfReader(input_stream)
        writer = PdfWriter()

        # Prüfen, ob die PDF beschädigt ist oder keine Seiten enthält
        if len(reader.pages) == 0:
            raise ValueError("Die PDF-Datei enthält keine Seiten oder ist leer.")

        # Schutzstufen-Konfiguration ermitteln(Basic, Medium oder High)
        config = get_schutzstufe_config(stufe)
        stufe_name = "high" if config["level"] == 3 else ("medium" if config["level"] == 2 else "basic")

        # 2. Seiten nacheinander kopieren
        for page in reader.pages:
            writer.add_page(page)

        # 3. Metadaten je nach Stufe ansetzen
        writer.add_metadata({
            "/Title": f"Anti-AI-Shield Protected [{stufe_name.upper()}]",
            "/Subject": config["text"],
            "/Producer": "Anti-AI-Shield Engine"
        })

        # 4. Je nach Stufe Einschränkungen hinzufügen (z.B. im High-Modus Textkopierschutz via Verschlüsselung)
        if config["level"] == 3:
            # Im High-Mode wird die PDF mit einem zufälligen Passwort verschlüsselt
            # und das Extrahieren von Text/Inhalten für KI-Scraper unterbunden.
            # (Das Dokument bleibt für normale Leser im PDF-Viewer bedienbar, sofern Permissions greifen)
            import secrets
            owner_pwd = secrets.token_hex(16)
            # Berechtigungs-Flag: Drucken erlaubt, aber Textextraktion/Kopieren deaktiviert
            try:
                writer.encrypt(
                    user_password="",
                    owner_password=owner_pwd,
                    permissions_flag=0b000001000000,
                )
            except TypeError:
                writer.encrypt(
                    user_pwd="",
                    owner_pwd=owner_pwd,
                    permissions_flag=0b000001000000,
                )

        # 5. Die bearbeitete PDF wieder in Bytes umwandeln
        output_stream = io.BytesIO()
        writer.write(output_stream)
        ergebnis_bytes = output_stream.getvalue()

        # 6. Neuen Dateinamen generieren
        neuer_dateiname = f"geschuetzt_{stufe_name}.pdf"
        return ergebnis_bytes, neuer_dateiname

    except Exception as e:
        # Fehler bei kaputten oder passwortgeschützten PDFs abfangen
        raise ValueError(f"Fehler beim Verarbeiten der PDF-Datei: {e}") from e