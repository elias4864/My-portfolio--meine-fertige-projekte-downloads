import io
from docx import Document
from docx.shared import Pt, RGBColor

SCHUTZSTUFEN = {
    "high": {
        "aliases": {"hard", "hoch", "high", "3"},
        "text": "Anti-AI-Shield [HIGH]: Scraping & automatisches Auslesen strengstens untersagt.",
        "color": (200, 0, 0),
        "level": 3,
    },
    "medium": {
        "aliases": {"medium", "mittel", "2"},
        "text": "Anti-AI-Shield [MEDIUM]: Urheberrechtlich geschützter Inhalt.",
        "color": (100, 100, 100),
        "level": 2,
    },
    "basic": {
        "aliases": {"basic", "easy", "niedrig", "1"},
        "text": "Anti-AI-Shield [BASIC]: Hinweis aktiv.",
        "color": (150, 150, 150),
        "level": 1,
    },
}


def get_schutzstufe_config(stufe: str) -> dict:
    """Normalisiert die Eingabe und liefert die einheitliche Schutzstufen-Konfiguration."""
    stufe_clean = str(stufe).strip().lower()
    for config in SCHUTZSTUFEN.values():
        if stufe_clean in config["aliases"]:
            return config
    return SCHUTZSTUFEN["basic"]


def _apply_footer_mark(footer, text: str, rgb: tuple[int, int, int], keep_existing: bool = False) -> None:
    """Schreibt den Markierungstext in einen Footer-Bereich, überprüft die Länge des Paragraphs und die Farbe etc."""
    if not keep_existing:
        # Bestehende Absätze im Footer leeren, damit keine doppelten Texte entstehen
        for p in list(footer.paragraphs[1:]):
            p._element.getparent().remove(p._element)

        if len(footer.paragraphs) > 0:
            footer_paragraph = footer.paragraphs[0]
            footer_paragraph.text = ""
        else:
            footer_paragraph = footer.add_paragraph()

        run = footer_paragraph.add_run(text)
        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(*rgb)
    else:
        if len(footer.paragraphs) > 0 and footer.paragraphs[-1].text.strip():
            footer_paragraph = footer.add_paragraph()
            run = footer_paragraph.add_run(text)
        elif len(footer.paragraphs) > 0:
            footer_paragraph = footer.paragraphs[-1]
            run = footer_paragraph.add_run(text)
        else:
            footer_paragraph = footer.add_paragraph()
            run = footer_paragraph.add_run(text)

        run.font.size = Pt(9)
        run.font.color.rgb = RGBColor(*rgb)


def mark_document_footer(doc_bytes: bytes, config: dict, neuer_name: str | None = None) -> tuple[bytes, str]:
    """Markiert die Fußzeile(n) eines DOCX-Dokuments anhand von `config`."""
    try:
        doc = Document(io.BytesIO(doc_bytes))

        text = config.get("text", "")
        r, g, b = config.get("color", (128, 128, 128))
        keep_existing = bool(config.get("keep_existing_footer", False))
        mark_first_page = bool(config.get("mark_first_page", True))

        for section in doc.sections:
            footer = section.footer
            _apply_footer_mark(
                footer, text=text, rgb=(r, g, b),
                keep_existing=keep_existing
            )

            # Bei 'Erste Seite anders' zusätzlich markieren
            if mark_first_page and section.different_first_page_header_footer:
                first_footer = section.first_page_footer
                _apply_footer_mark(
                    first_footer, text=text, rgb=(r, g, b),
                    keep_existing=keep_existing
                )

        output_io = io.BytesIO()
        doc.save(output_io)
        output_io.seek(0)

        ergebnis_bytes = output_io.getvalue()
        neuer_dateiname = neuer_name or "protected_dokument.docx"
        return ergebnis_bytes, neuer_dateiname

    except Exception as e:
        raise RuntimeError(f"Fehler beim Markieren der Fußzeile: {e}") from e


def process(inhalt: bytes, stufe: str, kennung: str | None = None, original_filename: str | None = None) -> tuple[bytes, str]:
    """Zentrale Prozessierungsfunktion für DOCX Dokumente."""
    if not inhalt or not isinstance(inhalt, bytes):
        raise ValueError("Fehler bei der Verarbeitung der Word-Datei: Datei ist leer oder ungültig.")

    config = get_schutzstufe_config(stufe)
    out_filename = "protected_dokument.docx"
    if original_filename:
        if "." in original_filename:
            base_name, ext = original_filename.rsplit(".", 1)
            out_filename = f"protected_{base_name}.{ext}"
        else:
            out_filename = f"protected_{original_filename}.docx"

    try:
        return mark_document_footer(inhalt, config, out_filename)
    except Exception as e:
        raise ValueError(f"Fehler bei der Verarbeitung der Word-Datei: {e}") from e
