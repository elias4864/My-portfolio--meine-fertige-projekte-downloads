
"""
Verarbeitung von Excel-Dateien für den Anti-AI-Shield.
"""

import io

try:
    import pandas as pd
except ImportError:
    pd = None


def process(inhalt: bytes, stufe: str):
    """
    Verarbeitet Excel-Dateien für den Anti-AI-Shield.

    Args:
        inhalt: Excel-Datei als Bytes.
        stufe: Gewünschte Schutzstufe.

    Returns:
        Verarbeitete Bytes und neuer Dateiname.
    """

    if not isinstance(inhalt, bytes) or not inhalt:
        raise ValueError("Der Dateiinhalt ist leer oder ungültig.")

    erlaubte_stufen = {"basic", "medium", "high"}

    if stufe not in erlaubte_stufen:
        raise ValueError(f"Unbekannte Schutzstufe: {stufe}")

    try:
        # Excel-Datei aus Bytes laden
        excel_datei = io.BytesIO(inhalt)

        # Alle Tabellenblätter einlesen
        tabellenblaetter = pd.read_excel(
            excel_datei,
            sheet_name=None,
            engine="openpyxl"
        )

        if not tabellenblaetter:
            raise ValueError("Die Excel-Datei hat keine Tabellenblätter.")

        # Tabellenblätter verarbeiten
        verarbeitete_blaetter = {}

        for name, df in tabellenblaetter.items():

            # Schutzlogik integrieren
            verarbeitetes_df = df.copy()

            if stufe == "basic":
                pass

            elif stufe == "medium":
                pass

            elif stufe == "high":
                pass

            verarbeitete_blaetter[name] = verarbeitetes_df

        # Neue Excel-Datei erstellen
        output_io = io.BytesIO()

        with pd.ExcelWriter(
            output_io,
            engine="openpyxl"
        ) as writer:

            for name, df in verarbeitete_blaetter.items():
                df.to_excel(
                    writer,
                    sheet_name=name,
                    index=False
                )

        # Output vorbereiten
        output_io.seek(0)

        verarbeiteter_inhalt = output_io.getvalue()

        neuer_dateiname = "protected_dokument.xlsx"

        return verarbeiteter_inhalt, neuer_dateiname

    except Exception as e:
        raise ValueError(
            f"Fehler bei der Excel-Verarbeitung: {str(e)}"
        ) from e


# Nur beim direkten Start ausführen, nicht beim Import
if __name__ == "__main__":

    print("=== Anti-AI-Shield: Excel-Verarbeitung testen ===")

    # Test-Excel-Datei erstellen
    test_excel = io.BytesIO()

    test_daten = pd.DataFrame({
        "Name": ["Max", "Anna", "Peter"],
        "Alter": [25, 30, 28],
        "Beruf": ["Entwickler", "Designerin", "Analyst"]
    })

    with pd.ExcelWriter(test_excel, engine="openpyxl") as writer:
        test_daten.to_excel(
            writer,
            sheet_name="Testdaten",
            index=False
        )

    excel_inhalt = test_excel.getvalue()

    # Alle Schutzstufen testen
    for stufe in ["basic", "medium", "high"]:

        print("\nSchutzstufe:", stufe)

        try:
            verarbeiteter_inhalt, dateiname = process(
                excel_inhalt,
                stufe
            )

            # Prüfen, ob eine Datei zurückgegeben wurde
            print("Dateiname:", dateiname)
            print("Dateigrösse:", len(verarbeiteter_inhalt), "Bytes")

            # Prüfen, ob die erzeugte Excel-Datei lesbar ist
            pruefung = pd.read_excel(
                io.BytesIO(verarbeiteter_inhalt),
                engine="openpyxl"
            )

            print("Excel-Datei erfolgreich erstellt.")
            print("Anzahl Zeilen:", len(pruefung))
            print("Anzahl Spalten:", len(pruefung.columns))

        except Exception as e:
            print("Fehler beim Test:", str(e))

    print("\n=== Excel-Tests abgeschlossen ===")
