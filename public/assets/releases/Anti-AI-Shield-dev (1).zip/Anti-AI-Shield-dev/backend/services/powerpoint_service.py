"""Fügt Schutzstufen-Hinweise in PowerPoint-Folien ein."""

import io
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.util import Pt

# Einheitliche Definition der 3 Schutzstufen-Modi (High, Medium und Basic)
SCHUTZSTUFEN = {
    "high": {
        "aliases": {"hard", "hoch", "high", "3"},
        "text": "Anti-AI-Shield [HIGH]: Scraping & automatisches Auslesen strengstens untersagt.",
        "color": RGBColor(200, 0, 0),
        "font_size": Pt(16),
        "bold": True,
    },
    "medium": {
        "aliases": {"medium", "mittel", "2"},
        "text": "Anti-AI-Shield [MEDIUM]: Urheberrechtlich geschützter Inhalt.",
        "color": RGBColor(100, 100, 100),
        "font_size": Pt(14),
        "bold": False,
    },
    "basic": {
        "aliases": {"basic", "easy", "niedrig", "1"},
        "text": "Anti-AI-Shield [BASIC]: Hinweis aktiv.",
        "color": RGBColor(150, 150, 150),
        "font_size": Pt(12),
        "bold": False,
    },
}


def get_schutzstufe_config(stufe: str) -> dict:
    """Normalisiert die Eingabe und liefert die einheitliche Schutzstufen-Konfiguration."""
    stufe_clean = str(stufe).strip().lower()
    for config in SCHUTZSTUFEN.values():
        if stufe_clean in config["aliases"]:
            return config
    return SCHUTZSTUFEN["basic"]


def process(inhalt: bytes, stufe: str) -> tuple[bytes, str]:
    """Fügt jeder PPTX-Folie einen farbigen Hinweis hinzu und liefert das Ergebnis zurück.

    Die Hinweise sind sichtbare Markierungen, kein technischer Schutz vor Scraping.
    """
    try:
        # 1. PPTX-Bytes mit io.BytesIO in ein für python-pptx lesbares Format laden
        pptx_file = io.BytesIO(inhalt)
        prs = Presentation(pptx_file)

        # 2. Prüfen, ob Folien vorhanden sind
        if not prs.slides:
            raise ValueError(
                "Die PowerPoint-Präsentation enthält keine Folien und kann nicht verarbeitet werden."
            )

        # 3. Schutzstufe auswerten
        config = get_schutzstufe_config(stufe)

        # 4. Position dynamisch anhand der tatsächlichen Foliengröße berechnen untere und Obere Grenze des Powerpoints-Berehcnen
        margin_x = Pt(24)
        box_height = Pt(48)
        box_width = prs.slide_width - (2 * margin_x)
        pos_top = prs.slide_height - box_height - Pt(12)
        pox_down = prs.slide_height - Pt(12)

        # 5. Kennung auf jeder Folie einfügen
        for slide in prs.slides:
            textbox = slide.shapes.add_textbox(margin_x, pos_top, box_width, box_height)
            text_frame = textbox.text_frame
            text_frame.word_wrap = True

            paragraph = text_frame.paragraphs[0]
            run = paragraph.add_run()
            run.text = config["text"]
            run.font.size = config["font_size"]
            run.font.color.rgb = config["color"]
            run.font.bold = config["bold"]

        # 6. Bearbeitete Präsentation wieder in Bytes umwandeln (In-Memory)
        output_io = io.BytesIO()
        prs.save(output_io)
        output_io.seek(0)

        return output_io.getvalue(), "protected_praesentation.pptx"

    except Exception as e:
        raise ValueError(
            f"Fehler bei der Verarbeitung der PowerPoint-Datei: {e}"
        ) from e
