#Import für identifizierungs nummer
from identifier_service import create_identifier

try:
    from backend.config import PROTECTION_LEVELS
except ImportError:
    PROTECTION_LEVELS = {"easy", "hard"}

# Sicherstellen, dass es eine Sammlung (z. B. Set) der erlaubten Stufen ist
ALLOWED_LEVELS = frozenset(PROTECTION_LEVELS)

# TODO: Festlegen, welche Werte fuer die Schutzstufe erlaubt sind.
# Beispiel: "easy" und "hard". Was soll bei einem anderen Wert passieren?
# Liste mit den Akzeptierten Level
allowed_levels = ["easy", "hard"]

#Funktion zum prüfen der Level ob sie in erlaubten Schutlevels vorkommt von der Liste (easy oder hard) vorkommt ansonsten false
def is_valid_level(level):
    #Wenn das eingegebene Leve in d der Errluabten Sammlung der Schutzstufen vorkommt
    return level in ALLOWED_LEVELS


def validate_difficulty_level(level: str) -> str:
    """Gibt die Stufe zurück, wenn sie erlaubt ist, sonst ValueError."""
    if not is_valid_level(level):
        erlaubt = ", ".join(sorted(ALLOWED_LEVELS))
        raise ValueError(f"Ungültige Schutzstufe '{level}'. Erlaubt sind: {erlaubt}")
    return level

# TODO: Die Bedeutung der Stufen gemeinsam festlegen, bevor ihr sie programmiert.
# Beispielidee (noch kein fertiger Schutz): easy = Kennung in der Fusszeile;
# hard = Fusszeile plus deutlich sichtbarer Hinweis.

#Dixonar mit den Verschiedenen  Levels
protection_levels ={
    "easy":"Einfache Erkennung",
    "hard":"Erweiterte(Eingeschränkte mit HardModus) Erkennung",
}

#Einfacher dixonar auswählen
print(protection_levels["easy"])

#Schwierige ausgabe
selectet_level ="hard"
print(protection_levels["hard"])
def valid_selected_level(selected_level):
    return selected_level in protection_levels

# TODO: Eine kleine Funktion planen, die Stufe und Kennung entgegennimmt.
# Beispel: create_marking("KLS-A1B2C3", "Biologie") -> lesbarer Kennzeichnungstext



def create_marking(identifier: str, level: str, subject: str | None = None) -> str:
    """
        Erzeugt anhand von Kennung (identifier), Schutzstufe (level) und optional
        einem Fach (subject) einen lesbaren Kennzeichnungstext.
        - 'easy': Kennung (und ggf. Fachkürzel) in der Fusszeile
        - 'hard': Fusszeile plus deutlich sichtbarer Hinweis
        """
    if not identifier or not str(identifier).strip():
        raise ValueError("Die Kennung (identifier) darf nicht leer sein.")

    validated_level = validate_difficulty_level(level)

    kennungen_teil = identifier.strip()
    if subject and subject.strip():
        subject_code = subject.strip().upper()[:3]
        kennungen_teil = f"{kennungen_teil}-{subject_code}"

    level_label = LEVEL_DESCRIPTIONS.get(validated_level, validated_level)
    footer = f"Fusszeile: Kennung {kennungen_teil} (Stufe: {level_label})"

    if validated_level == "easy":
        return footer

    if validated_level == "hard":
        notice = (
            f": Dieses Dokument ist mit der eingeschränkten Kennungsmodus  "
            f"{kennungen_teil} gekennzeichnet."
        )
        return f"{notice}\n{footer}"

    return footer




#Tests für Identifier
if __name__ == "__main__":
    identifier = create_identifier()
    print(create_marking(identifier, "easy"))
    print("---")
    print(create_marking(identifier, "hard"))