"""Stellt die erweiterte Verarbeitungsschnittstelle für TXT-Dateien bereit."""

# TODO: chardet ist nicht in requirements.txt enthalten. Als Abhängigkeit
# deklarieren oder optional importieren, damit das Backend ohne Paket startet.

def _sichere_dekodierung(inhalt: bytes) -> str:
    """Erkennt die Kodierung intelligent oder nutzt sichere Fallbacks."""
    # Versuche es zuerst mit modernem UTF-8
    try:
        return inhalt.decode("utf-8")
    except UnicodeDecodeError:
        pass

    # Optionaler Fallback mit chardet, falls installiert, sonst Latin-1
    try:
        import chardet
        detection = chardet.detect(inhalt)
        encoding = detection.get("encoding")
        if encoding:
            return inhalt.decode(encoding, errors="replace")
    except ImportError:
        pass

    # Letzter Fallback
    return inhalt.decode("latin-1", errors="replace")


def process(inhalt: bytes, stufe: str, original_filename: str = "dokument.txt") -> tuple[bytes, str]:
    """
    Verarbeitet TXT-Dateien für den Anti-AI-Shield.
    Kümmert sich um sichere Textkodierung, Schutzstufen-Anpassung und Dateinamen-Generierung bei TXT-Datenformat.
    """
    # 1. Bytes sicher in einen String dekodieren (Erweiterte Textkodierung)
    text = _sichere_dekodierung(inhalt)

    # TODO: Die Kennzeichnung und das Verhalten für easy/hard fachlich festlegen;
    # aktuell unterscheiden sich die Schutzstufen im TXT-Ergebnis nicht.
    prefix = f"--- [GESCHÜTZT DURCH ANTI-AI-SHIELD | STUFE: {stufe.upper()}] ---\n\n"
    protected_text = prefix + text

    # 3. Wieder in UTF-8 Bytes kodieren
    verarbeiteter_inhalt = protected_text.encode("utf-8")

    # 4. Dynamischen Dateinamen basierend auf dem Original erzeugen
    if original_filename:
        if "." in original_filename:
            base_name = original_filename.rsplit(".", 1)[0]
            neuer_dateiname = f"protected_{base_name}.txt"
        else:
            neuer_dateiname = f"protected_{original_filename}.txt"
    else:
        neuer_dateiname = "verarbeitetes_dokument.txt"

    return verarbeiteter_inhalt, neuer_dateiname