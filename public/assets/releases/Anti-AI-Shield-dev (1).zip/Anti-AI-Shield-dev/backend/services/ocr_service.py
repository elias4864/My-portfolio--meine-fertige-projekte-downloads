import io
import re
from fastapi import FastAPI, File, UploadFile, HTTPException
import pytesseract
from PIL import Image
from pdf2image import convert_from_bytes


app = FastAPI(title="OCR File-Upload Anti-AI Shield Service")

# Konfiguration: 5 MB in Bytes (5 * 1024 * 1024)
MAX_FILE_SIZE = 5 * 1024 * 1024

ALLOWED_CONTENT_TYPES = [
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/tiff",
    "application/pdf"
]

# Regulärer Ausdruck für das Kennungsformat (Beispiel: KLS-A1B2C3)
KENNUNG_REGEX = r"KLS-[A-Z0-9]{6}"


@app.post("/ocr-upload/")
async def extract_text_from_file(file: UploadFile = File(...)):
    content_type = file.content_type

    # 1. Dateiformat validieren
    if content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Dateityp '{content_type}' wird nicht unterstützt. Bitte PNG, JPG, WEBP, TIFF oder PDF hochladen."
        )

    try:
        # Wir lesen maximal MAX_FILE_SIZE + 1 Bytes ein. Ist die Datei größer, ist len(file_bytes) > MAX_FILE_SIZE.
        file_bytes = await file.read(MAX_FILE_SIZE + 1)

        # 2.Maximale  Dateigröße validieren (max. 5 MB)
        if len(file_bytes) > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=400,
                detail="Die Datei ist zu groß. Die maximale Dateigröße beträgt 5 MB."
            )

        extracted_text = ""

        # Fall 1: Die hochgeladene Datei ist ein Bild
        if content_type in ["image/jpeg", "image/png", "image/webp", "image/tiff"]:
            image = Image.open(io.BytesIO(file_bytes))
            # 'lang="deu"' sorgt für eine bessere Erkennung von Umlauten (ä, ö, ü, ß)
            extracted_text = pytesseract.image_to_string(image, lang="deu")

        # Fall 2: Die hochgeladene Datei ist ein PDF
        elif content_type == "application/pdf":
            images = convert_from_bytes(file_bytes)
            for page_num, image in enumerate(images, start=1):
                page_text = pytesseract.image_to_string(image, lang="deu")
                extracted_text += f"--- Seite {page_num} ---\n{page_text}\n"

        elif not content_type:
            raise HTTPException(
                status_code=400,
                detail="Der Dateityp konnte nicht ermittelt werden."
            )

        cleaned_text = extracted_text.strip()

        # 3. Prüfen, ob das Dokument lesbar ist (ob Text erkannt wurde)
        if not cleaned_text:
            return {
                "dateiname": file.filename,
                "dateityp": content_type,
                "status": "unlesbar",
                "meldung": "Es konnte kein Text im Dokument erkannt werden (möglicherweise leer oder unleserliches Bild).",
                "erkannte_kennung": None,
                "erkanntes_text_ergebnis": ""
            }

        # 4. Nach dem Kennungsformat suchen
        match = re.search(KENNUNG_REGEX, cleaned_text, re.IGNORECASE)

        if match:
            gefundene_kennung = match.group(0)
            status = "gefunden"
        else:
            gefundene_kennung = None
            status = "nicht_gefunden"

        return {
            "dateiname": file.filename,
            "dateityp": content_type,
            "status": status,
            "erkannte_kennung": gefundene_kennung,
            "erkanntes_text_ergebnis": cleaned_text
        }

    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Fehler bei der OCR-Verarbeitung: {str(e)}"
        )