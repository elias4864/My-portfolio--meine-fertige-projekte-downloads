import inspect
import uuid
from datetime import datetime, timezone

from backend.config import PROTECTION_LEVELS
from backend.services import excel_service, pdf_service, ppt_service, txt_service, word_service
from backend.utils.file_validation import validate_upload


def _supports_kennung(processor) -> bool:
    """Überprüft ob ein Service aktuell ein bestimmtes Keyword-Argument wie 'kennung' im Input akzeptiert."""
    params = inspect.signature(processor).parameters
    return "kennung" in params or any(
        p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()
    )


def generate_tracking_id() -> str:
    """Erzeugt eine eindeutige Kennungsnummer (ID) für das geschützte Dokument."""
    datum = datetime.now(timezone.utc).strftime("%Y%m%d")
    kurz_uuid = uuid.uuid4().hex[:8].upper()
    return f"AAS-{datum}-{kurz_uuid}"


def process_document(filename: str, file_bytes: bytes, level: str) -> tuple[bytes, str]:
    """Prüft Datei und Schutzstufe, erzeugt eine Kennung und gibt Ergebnis-Bytes samt Dateiname zurück."""
    validate_upload(filename, file_bytes)

    # Normalisiere Stufe auf Kleinbuchstaben
    normalized_level = str(level).strip().lower()
    level_map = {
        "easy": "easy",
        "hard": "hard",
        "basic": "easy",
        "medium": "easy",
        "high": "hard",
        "hoch": "hard",
        "niedrig": "easy",
    }
    canonical_level = level_map.get(normalized_level)

    if not canonical_level and normalized_level not in PROTECTION_LEVELS:
        allowed = ", ".join(sorted(PROTECTION_LEVELS))
        raise ValueError(f"Ungültige Schutzstufe '{level}'. Erlaubt sind: {allowed}.")

    final_level = canonical_level or normalized_level
    kennung = generate_tracking_id()

    extension = filename.rsplit(".", maxsplit=1)[-1].lower()
    processors = {
        "pdf": pdf_service.process,
        "docx": word_service.process,
        "pptx": ppt_service.process,
        "txt": txt_service.process,
        "xls": excel_service.process,
        "xlsx": excel_service.process,
    }

    processor = processors.get(extension)
    if processor is None:
        raise ValueError(f"Der Dateityp '.{extension}' wird nicht unterstützt.")

    kwargs = {}
    params = inspect.signature(processor).parameters
    if "kennung" in params or any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
        kwargs["kennung"] = kennung
    if "original_filename" in params:
        kwargs["original_filename"] = filename

    return processor(file_bytes, final_level, **kwargs)
