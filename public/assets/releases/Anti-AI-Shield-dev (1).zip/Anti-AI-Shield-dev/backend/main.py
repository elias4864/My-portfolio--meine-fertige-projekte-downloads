"""Startet die FastAPI-Anwendung und registriert ihre Endpunkte mit CORS-Unterstützung."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.config import ALLOWED_EXTENSIONS, MAX_FILE_SIZE_MB, PROTECTION_LEVELS
from backend.routes.process import router as process_router

app = FastAPI(
    title="Anti-AI DocShield API",
    description="Backend API zur Absicherung von Prüfungs- und Lerndokumenten gegen KI-Scraping und Prüfungsbetrug.",
    version="1.0.0",
)

# CORS Middleware für Next.js Frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)

app.include_router(process_router)


@app.get("/health")
def health() -> dict[str, str]:
    """Gibt den Status der laufenden API zurück."""
    return {"status": "ok", "app": "Anti-AI DocShield", "version": "1.0.0"}


@app.get("/api/config")
def get_config() -> dict:
    """Gibt die aktuelle Konfiguration zurück für das Frontend."""
    return {
        "allowed_extensions": sorted(list(ALLOWED_EXTENSIONS)),
        "max_file_size_mb": MAX_FILE_SIZE_MB,
        "protection_levels": [
            {
                "id": "easy",
                "name": "Einfacher Modus (Basic)",
                "description": "Urheberrechtliche Metadaten, dezente Wasserzeichen und Prüfungs-Tracking-ID.",
            },
            {
                "id": "hard",
                "name": "Strenger Prüfungsmodus (Exam Shield)",
                "description": "Vollständige KI-Extraktionsblockade, Verschlüsselung, prominente Anti-Cheat-Warnungen und Anti-Scraping-Restriktionen.",
            },
        ],
    }
