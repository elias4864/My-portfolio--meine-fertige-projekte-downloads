import pathlib
import tempfile


def process_temp_storage(
    filename: str, datei_bytes: bytes, stufe: str
) -> tuple[bytes, str]:
    """Verarbeitet eine Datei über temporäre Speicherorte (temp-Files)
    und gibt die verarbeiteten Bytes sowie den neuen Dateinamen zurück.
    """
    # Dateinamen bereinigen (schützt vor Path Traversal wie "../../etc/passwd")
    safe_filename = pathlib.Path(filename).name
    if not safe_filename:
        raise ValueError("Ungültiger Dateiname übergeben.")

    # Temporären Speicherort vorbereiten
    with tempfile.TemporaryDirectory() as temp_dir_str:
        temp_dir = pathlib.Path(temp_dir_str)

        # 1. Hochgeladene Datei vorübergehend speichern
        input_file_path = temp_dir / safe_filename
        input_file_path.write_bytes(datei_bytes)
        print(f"Die hochgeladene Datei wurde temporär unter: {input_file_path} gespeichert")

        # 2. Dateipfade für Weiterverarbeitung bereitstellen
        output_filename = f"Protected_{safe_filename}"
        output_file_path = temp_dir / output_filename
        print(f"[Temp-Storage] Pfade für Verarbeitung bereitgestellt (Stufe: {stufe}).")

        # 3. Verarbeitete Dateien vorübergehend speichern (Beispiel-Logik)
        # (Im echten Code hier die docx/pdf-Verarbeitung für Hard-Mode aufrufen)
        processed_bytes = datei_bytes  # Platzhalter für das echte Ergebnis
        output_file_path.write_bytes(processed_bytes)
        print(f"[Temp-Storage] Verarbeitete Datei temporär gespeichert unter: {output_file_path}")

        # 4. Verarbeitete Bytes zum Rückgabewert einlesen, bevor der Ordner gelöscht wird
        ergebnis_bytes = output_file_path.read_bytes()

        # 5. Dateien nach der Rückgabe zur Löschung freigeben
        # Sobald der 'with'-Block verlassen wird, löscht Python den Temp-Ordner automatisch.
        return ergebnis_bytes, output_filename


if __name__ == "__main__":
    test_document = "elias.docx"
    test_bytes = b"Dies ist eine Testnachricht"

    try:
        loesungs_bytes, neuer_name = process_temp_storage(
            test_document, test_bytes, stufe="hoch"
        )
        print(f"Erfolgreich! Neuer Name: {neuer_name}, Bytelänge: {len(loesungs_bytes)}")
    except Exception as e:
        print(f"Ein Fehler ist aufgetreten: {e}")