import logging
import shutil
import tempfile
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

logger = logging.getLogger(__name__)

# Eindeutiger Präfix, damit keine fremden Temp-Dateien aus Versehen gelöscht werden
PROJEKT_TEMP_PREFIX = "anti_ai_shield_"


@contextmanager
def sichere_verarbeitung(im_speicher: bool = True) -> Iterator[Path | None]:
    """Entscheidet, ob im Arbeitsspeicher oder mit temporären Dateien gearbeitet wird.
    Bereinigt ausschließlich eigene Projekt-Temp-Dateien, selbst bei Fehlern.
    """
    temp_dir: Path | None = None

    try:
        if im_speicher:
            print("-> Modus: Verarbeitung im Arbeitsspeicher (In-Memory).")
            yield None
        else:
            temp_dir = Path(tempfile.mkdtemp(prefix=PROJEKT_TEMP_PREFIX))
            print(f"-> Modus: Temporäres Verzeichnis erstellt: {temp_dir}")
            yield temp_dir

    except Exception as e:
        print(f"-> Achtung: Verarbeitung wurde mit einem Fehler abgebrochen: {e}")
        raise

    finally:
        if temp_dir is not None and temp_dir.exists():
            # Sicherheits-Check: Nur löschen, wenn der Ordner wirklich unser Projekt-Präfix trägt
            if temp_dir.name.startswith(PROJEKT_TEMP_PREFIX):
                try:
                    print("-> Starte Bereinigung der eigenen Projekt-Temp-Dateien...")
                    shutil.rmtree(temp_dir)
                    logger.debug("Projekt-Temp-Verzeichnis entfernt: %s", temp_dir)
                    print("-> Bereinigung abgeschlossen. Eigene Temp-Dateien entfernt.")
                except OSError as cleanup_err:
                    logger.warning(
                        "Temp-Verzeichnis konnte nicht vollständig entfernt werden (%s): %s",
                        temp_dir,
                        cleanup_err,
                    )
            else:
                logger.warning(
                    "Sicherheitsabbruch: Verzeichnis '%s' gehört nicht zum Projekt und wurde nicht gelöscht.",
                    temp_dir,
                )
        else:
            print("-> Keine temporären Festplattendateien zu bereinigen.")