"use client";

import React, { useState } from "react";
import { CheckCircle2, XCircle, Search, Shield, Calendar, Hash, FileCheck2 } from "lucide-react";

export default function TrackingVerifier() {
  const [inputCode, setInputCode] = useState("");
  const [verificationResult, setVerificationResult] = useState<{
    valid: boolean;
    trackingId: string;
    date?: string;
    format?: string;
    details?: string;
  } | null>(null);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    const code = inputCode.trim().toUpperCase();

    // AAS Format: AAS-YYYYMMDD-XXXXXXXX (8 hex)
    const aasMatch = code.match(/^AAS-(\d{4})(\d{2})(\d{2})-([0-9A-F]{8})$/);
    // KLS Format: KLS-XXXXXX (6 alphanumeric)
    const klsMatch = code.match(/^KLS-([A-Z0-9]{6})$/);

    if (aasMatch) {
      const [_, year, month, day, hash] = aasMatch;
      setVerificationResult({
        valid: true,
        trackingId: code,
        date: `${day}.${month}.${year}`,
        format: "Anti-AI-Shield Version 2.0 (AAS Standard)",
        details: `Echtes Prüfungsdokument ausgestellt am ${day}.${month}.${year}. Hash-Signatur: ${hash}. Dokumentenschild aktiv.`,
      });
    } else if (klsMatch) {
      setVerificationResult({
        valid: true,
        trackingId: code,
        date: "Vorheriges Semester",
        format: "KI-Lernschutz Legacy (KLS Format)",
        details: "Gültiges Prüfungs-Kennzeichen der ersten Generation. Registriert in der Universitätsdatenbank.",
      });
    } else {
      setVerificationResult({
        valid: false,
        trackingId: code,
        details: "Ungültiges Kennungs-Format. Erwartetes Format: AAS-JJJJMMTT-XXXXXXXX oder KLS-XXXXXX.",
      });
    }
  };

  const sampleCodes = ["AAS-20261126-E4A4E07C", "KLS-AB12CD", "AAS-20261015-8F3B91D2"];

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
          Prüfungsdokument & ID verifizieren
        </h2>
        <p className="text-xs sm:text-sm text-slate-400">
          Prüfen Sie anhand der im Dokument eingebetteten Kennung die Echtheit und den Schutzstatus einer Klausur.
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 backdrop-blur-xl">
        <form onSubmit={handleVerify} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Prüfungs-Tracking-ID eingeben
            </label>
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Hash className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  value={inputCode}
                  onChange={(e) => setInputCode(e.target.value)}
                  placeholder="z. B. AAS-20261126-E4A4E07C"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-slate-100 placeholder-slate-600 font-mono text-sm focus:outline-none focus:border-emerald-500"
                />
              </div>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center space-x-2 transition"
              >
                <Search className="w-4 h-4" />
                <span>Verifizieren</span>
              </button>
            </div>
          </div>

          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <span>Beispiel-IDs testen:</span>
            {sampleCodes.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setInputCode(c)}
                className="text-emerald-400 hover:underline font-mono text-[11px]"
              >
                {c}
              </button>
            ))}
          </div>
        </form>

        {/* Result Display */}
        {verificationResult && (
          <div className="mt-6 pt-6 border-t border-slate-800">
            {verificationResult.valid ? (
              <div className="p-5 rounded-xl bg-emerald-950/20 border border-emerald-500/40 space-y-3">
                <div className="flex items-center space-x-3 text-emerald-400">
                  <CheckCircle2 className="w-6 h-6 shrink-0" />
                  <div>
                    <h4 className="font-bold text-sm text-white">Gültiges Prüfungsdokument</h4>
                    <p className="text-xs text-emerald-400/90 font-mono">{verificationResult.trackingId}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs font-mono">
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">STANDARD</span>
                    <span className="text-slate-200">{verificationResult.format}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <span className="text-slate-500 block text-[10px]">DATUM</span>
                    <span className="text-slate-200">{verificationResult.date}</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 pt-1 leading-relaxed">
                  {verificationResult.details}
                </p>
              </div>
            ) : (
              <div className="p-5 rounded-xl bg-red-950/20 border border-red-500/40 flex items-start space-x-3 text-red-300">
                <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <h4 className="font-bold text-white">Prüfung fehlgeschlagen</h4>
                  <p>{verificationResult.details}</p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
