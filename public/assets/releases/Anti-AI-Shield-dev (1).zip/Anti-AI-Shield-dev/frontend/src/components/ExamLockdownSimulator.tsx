"use client";

import React, { useState, useEffect } from "react";
import {
  ShieldAlert,
  Maximize2,
  Minimize2,
  Copy,
  AlertOctagon,
  Clock,
  Eye,
  Lock,
  CheckCircle2,
  RefreshCw,
  Bell,
} from "lucide-react";

export default function ExamLockdownSimulator() {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [violations, setViolations] = useState<string[]>([]);
  const [blockedCopyCount, setBlockedCopyCount] = useState(0);
  const [alertToast, setAlertToast] = useState<string | null>(null);
  const [timerSeconds, setTimerSeconds] = useState(45 * 60); // 45 Min Exam
  const [isExamActive, setIsExamActive] = useState(true);

  // Timer Countdown
  useEffect(() => {
    if (!isExamActive || timerSeconds <= 0) return;
    const interval = setInterval(() => {
      setTimerSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [isExamActive, timerSeconds]);

  // Tab-Wechsel & Blur-Überwachung (Verlassen des Prüfungsfensters)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === "hidden") {
        const time = new Date().toLocaleTimeString();
        const msg = `[${time}] Prüfungs-Tab verlassen! Mögliche KI-Suche (ChatGPT / Claude) erkannt.`;
        setViolations((prev) => [msg, ...prev.slice(0, 9)]);
        triggerAlert("🚨 WARNUNG: Tab-Wechsel erkannt! Prüfungsaufsicht benachrichtigt.");
      }
    };

    const handleWindowBlur = () => {
      const time = new Date().toLocaleTimeString();
      const msg = `[${time}] Fokus auf externe Anwendung verloren (z.B. AI-Assistent im Hintergrund).`;
      setViolations((prev) => [msg, ...prev.slice(0, 9)]);
      triggerAlert("⚠️ ACHTUNG: Fenster-Fokus verloren!");
    };

    window.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("blur", handleWindowBlur);

    return () => {
      window.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("blur", handleWindowBlur);
    };
  }, []);

  // Kopierschutz & Kontextmenü-Sperre
  useEffect(() => {
    const handleCopy = (e: ClipboardEvent) => {
      e.preventDefault();
      setBlockedCopyCount((prev) => prev + 1);
      const time = new Date().toLocaleTimeString();
      setViolations((prev) => [
        `[${time}] Unbefugter Kopierversuch (Clipboard geblockt - keine KI-Übergabe erlaubt).`,
        ...prev.slice(0, 9),
      ]);
      triggerAlert("🚫 KOPIERSCHUTZ AKTIV: Prüfungsfragen dürfen nicht an KI-Tools übergeben werden!");
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      triggerAlert("🔒 Rechtsklick / Kontextmenü im Prüfungsmodus gesperrt.");
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+C, Ctrl+X, Ctrl+U (Quelltext), F12 (DevTools), PrintScreen
      if (
        (e.ctrlKey && (e.key === "c" || e.key === "C" || e.key === "x" || e.key === "u")) ||
        e.key === "F12" ||
        e.key === "PrintScreen"
      ) {
        e.preventDefault();
        setBlockedCopyCount((prev) => prev + 1);
        triggerAlert("🛑 Tastaturkürzel (Kopieren / DevTools / Screenshot) ist für Studenten gesperrt!");
      }
    };

    document.addEventListener("copy", handleCopy);
    document.addEventListener("contextmenu", handleContextMenu);
    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("copy", handleCopy);
      document.removeEventListener("contextmenu", handleContextMenu);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  const triggerAlert = (text: string) => {
    setAlertToast(text);
    setTimeout(() => {
      setAlertToast((curr) => (curr === text ? null : curr));
    }, 4000);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const formatTimer = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Toast Alert */}
      {alertToast && (
        <div className="fixed top-20 right-6 z-50 max-w-md p-4 rounded-xl bg-red-950 border border-red-500/80 text-red-100 shadow-2xl flex items-start space-x-3 animate-bounce">
          <AlertOctagon className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <p className="font-bold uppercase tracking-wider text-red-400">Prüfungssicherheits-Alarm</p>
            <p className="mt-0.5 text-slate-200">{alertToast}</p>
          </div>
        </div>
      )}

      {/* Header Info Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 backdrop-blur-xl">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center space-x-2">
              <span>Studenten-Prüfungsmodus (Exam Lockdown)</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-red-950 text-red-400 border border-red-800">
                AKTIV
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              Simuliert die automatische Beschränkung von Studenten während digitaler Klausuren.
            </p>
          </div>
        </div>

        {/* Exam Controls & Timer */}
        <div className="flex items-center space-x-3 w-full sm:w-auto justify-between sm:justify-end">
          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs">
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-slate-300">Restzeit:</span>
            <span className="font-bold text-emerald-400">{formatTimer(timerSeconds)}</span>
          </div>

          <button
            onClick={toggleFullscreen}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 font-medium transition"
          >
            {isFullscreen ? (
              <>
                <Minimize2 className="w-3.5 h-3.5" />
                <span>Vollbild beenden</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Vollbild sperren</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Grid: Mock Exam Paper on Left, Restriction Monitor on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Protected Exam Paper Simulator (2 cols) */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden">
          {/* Watermark Overlay */}
          <div className="absolute inset-0 pointer-events-none select-none flex items-center justify-center opacity-5 rotate-[-25deg]">
            <span className="text-6xl font-black tracking-widest text-red-500 uppercase">
              ANTI-AI EXAM SHIELD • KLS-2026
            </span>
          </div>

          <div className="space-y-4">
            <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                  KLAUSUR-DOKUMENT
                </span>
                <h3 className="text-base font-bold text-white mt-1">
                  Modulprüfung: Künstliche Intelligenz & Datenintegrität
                </h3>
              </div>
              <div className="text-right text-[11px] font-mono text-slate-400">
                <p>Tracking-ID: AAS-20261126-KLS789A</p>
                <p className="text-red-400">Modus: Streng (Hard)</p>
              </div>
            </div>

            {/* Warning Banner inside exam */}
            <div className="p-3 rounded-lg bg-red-950/30 border border-red-900/50 flex items-center space-x-2.5 text-xs text-red-300">
              <Lock className="w-4 h-4 text-red-400 shrink-0" />
              <span>
                <strong>Prüfungshinweis:</strong> Jegliches Kopieren des Inhalts sowie die Eingabe in LLMs (ChatGPT, Claude etc.) wird protokolliert und führt zum Prüfungsabbruch.
              </span>
            </div>

            {/* Exam Content with Anti-Copy Test */}
            <div className="space-y-4 text-xs leading-relaxed text-slate-300 select-text p-4 rounded-xl bg-slate-950/70 border border-slate-800/60">
              <p className="font-semibold text-slate-100">
                Aufgabe 1 (15 Punkte): Vergleichende Analyse
              </p>
              <p>
                Erläutern Sie das Funktionsprinzip von Transformer-Architekturen im Kontext von Self-Attention.
                Welche strukturellen Schwachstellen weisen Large Language Models bei der Erkennung von
                adversarialen Zeichenfolgen und versteckten Null-Breite-Zeichen (Zero-Width Tokens) auf?
              </p>

              <div className="p-3 rounded bg-slate-900/90 border border-slate-800 font-mono text-[11px] text-slate-400">
                <span className="text-emerald-400">// Interaktiver Test für Studenten:</span>
                <br />
                Versuchen Sie diesen Text zu markieren und mit <strong>Strg+C</strong> zu kopieren oder mit <strong>Rechtsklick</strong> das Menü zu öffnen.
              </div>

              <p className="font-semibold text-slate-100 pt-2">
                Aufgabe 2 (20 Punkte): Algorithmische Sicherheitsmechanismen
              </p>
              <p>
                Skizzieren Sie ein mathematisches Modell, mit dem ein Prüfungs-Dokumentenschild
                automatisierte Textextraktion durch gezielte Störung der Vektor-Einbettungen verhindert,
                während die Lesbarkeit für das menschliche Auge unverändert bleibt.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 font-mono">
              <span>Anti-AI-Shield v1.0 • Eingeschränkte Studentenansicht</span>
              <span>Seite 1 von 1</span>
            </div>
          </div>
        </div>

        {/* Right: Restriction & Violation Monitor (1 col) */}
        <div className="space-y-4">
          {/* Security Stats */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-2">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>Echtzeit-Prüfungsaufsicht</span>
            </h4>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                <p className="text-2xl font-extrabold text-red-400 font-mono">
                  {blockedCopyCount}
                </p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Blockierte Kopierversuche
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-center">
                <p className="text-2xl font-extrabold text-amber-400 font-mono">
                  {violations.length}
                </p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Fokus- & Tab-Verstöße
                </p>
              </div>
            </div>

            {/* Active Protections Checklist */}
            <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
              <p className="text-[11px] font-semibold text-slate-300">Aktive Restriktionen:</p>
              <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Zwischenablage / Clipboard gesperrt</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Entwicklertools (F12) deaktiviert</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Tab-Wechsel & Blur-Überwachung aktiv</span>
              </div>
              <div className="flex items-center space-x-2 text-slate-400 text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span>Anti-AI Wasserzeichen eingebettet</span>
              </div>
            </div>
          </div>

          {/* Audit Log */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center space-x-1.5">
                <Bell className="w-3.5 h-3.5 text-amber-400" />
                <span>Sicherheits-Protokoll</span>
              </h4>
              {violations.length > 0 && (
                <button
                  onClick={() => setViolations([])}
                  className="text-[10px] text-slate-400 hover:text-slate-200"
                >
                  Leeren
                </button>
              )}
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
              {violations.length === 0 ? (
                <p className="text-[11px] text-slate-500 italic py-2">
                  Noch keine verdächtigen Aktivitäten protokolliert. Wechseln Sie den Tab oder kopieren Sie Text, um das System zu testen.
                </p>
              ) : (
                violations.map((v, i) => (
                  <div
                    key={i}
                    className="p-2 rounded bg-slate-950 border border-slate-800/80 font-mono text-[10px] text-amber-300/90 leading-tight"
                  >
                    {v}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
