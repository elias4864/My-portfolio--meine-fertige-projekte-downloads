"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Upload,
  FileText,
  Shield,
  ShieldAlert,
  CheckCircle,
  AlertCircle,
  Download,
  ArrowRight,
  FileCheck,
  Lock,
  EyeOff,
  Sparkles,
  Loader2,
} from "lucide-react";
import {
  processDocument,
  triggerFileDownload,
  getBackendConfig,
  BackendConfig,
  ProcessDocumentResult,
} from "@/lib/api";

interface DocumentUploaderProps {
  onSwitchToSimulator?: () => void;
}

export default function DocumentUploader({ onSwitchToSimulator }: DocumentUploaderProps) {
  const [file, setFile] = useState<File | null>(null);
  const [protectionLevel, setProtectionLevel] = useState<"easy" | "hard">("hard");
  const [isProcessing, setIsProcessing] = useState(false);
  const [progressStage, setProgressStage] = useState(0);
  const [result, setResult] = useState<ProcessDocumentResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [config, setConfig] = useState<BackendConfig | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    getBackendConfig()
      .then(setConfig)
      .catch((err) => console.warn("Konnte Backend-Konfiguration nicht laden", err));
  }, []);

  const stages = [
    "Dateistruktur analysieren & Signatur validieren...",
    "Eindeutige Prüfungs-Tracking-ID generieren...",
    "Anti-LLM Extraktionsbarrieren & Wasserzeichen anwenden...",
    protectionLevel === "hard"
      ? "Anti-Scraper Verschlüsselung & Kopierberechtigungen sperren..."
      : "Metadaten & dezenten Urheberrechtsschutz einbetten...",
    "Prüfungsdokument finalisieren & Download vorbereiten...",
  ];

  const handleFileSelect = (selectedFile: File) => {
    setErrorMessage(null);
    setResult(null);

    const ext = "." + selectedFile.name.split(".").pop()?.toLowerCase();
    const allowed = config?.allowed_extensions || [".docx", ".pdf", ".pptx", ".txt"];

    if (!allowed.includes(ext)) {
      setErrorMessage(`Dateityp '${ext}' nicht unterstützt. Erlaubt: ${allowed.join(", ")}`);
      return;
    }

    const maxMb = config?.max_file_size_mb || 10;
    if (selectedFile.size > maxMb * 1024 * 1024) {
      setErrorMessage(`Datei zu groß (${(selectedFile.size / (1024 * 1024)).toFixed(1)} MB). Maximal: ${maxMb} MB.`);
      return;
    }

    setFile(selectedFile);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleProcess = async () => {
    if (!file) return;

    setIsProcessing(true);
    setErrorMessage(null);
    setProgressStage(0);

    // Virtueller Fortschrittsanzeiger für das Sicherheits-Feedback
    const interval = setInterval(() => {
      setProgressStage((prev) => (prev < stages.length - 1 ? prev + 1 : prev));
    }, 450);

    try {
      const res = await processDocument(file, protectionLevel);
      clearInterval(interval);
      setProgressStage(stages.length - 1);
      setResult(res);
    } catch (err: any) {
      clearInterval(interval);
      setErrorMessage(err.message || "Fehler beim Verarbeiten der Datei.");
    } finally {
      setIsProcessing(false);
    }
  };

  const resetForm = () => {
    setFile(null);
    setResult(null);
    setErrorMessage(null);
    setProgressStage(0);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(2) + " MB";
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-8">
      {/* Hero Banner */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono">
          <Sparkles className="w-3.5 h-3.5" />
          <span>KI-Prüfungsbetrug wirksam unterbinden</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
          Prüfungsdokumente vor{" "}
          <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
            KI-Scraping & Betrug
          </span>{" "}
          schützen
        </h1>
        <p className="text-slate-400 text-sm sm:text-base max-w-2xl mx-auto">
          Laden Sie Prüfungsbögen (PDF, Word, PPTX, TXT) hoch. Wählen Sie den einfachen oder strengen Schutzmodus,
          um das unbefugte Auslesen durch ChatGPT, Claude und OCR-Scanner technisch und organisatorisch zu blockieren.
        </p>
      </div>

      {/* Main Upload Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 backdrop-blur-xl shadow-2xl">
        {!result ? (
          <div className="space-y-6">
            {/* 1. Schutzstufen-Auswahl (Simple vs. Hard Mode) */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                1. Schutzstufe wählen
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Easy Mode */}
                <div
                  onClick={() => setProtectionLevel("easy")}
                  className={`relative p-5 rounded-xl border cursor-pointer transition-all ${
                    protectionLevel === "easy"
                      ? "border-emerald-500/60 bg-emerald-950/20 shadow-lg shadow-emerald-950/40 ring-1 ring-emerald-500/50"
                      : "border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-900/50"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-lg bg-emerald-900/40 text-emerald-400 border border-emerald-700/50">
                        <Shield className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-100 text-sm">
                          Einfacher Modus (Simple)
                        </h3>
                        <span className="text-[11px] text-emerald-400 font-mono">
                          Standard-Prüfung
                        </span>
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        protectionLevel === "easy"
                          ? "border-emerald-400 bg-emerald-400"
                          : "border-slate-600"
                      }`}
                    >
                      {protectionLevel === "easy" && (
                        <div className="w-1.5 h-1.5 bg-slate-950 rounded-full" />
                      )}
                    </div>
                  </div>
                  <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                    Fügt sichtbare Urheberrechtshinweise in Fußzeilen ein, setzt Metadaten-Schutz und generiert eine individuelle Prüfungs-Tracking-ID (AAS-...).
                  </p>
                  <ul className="mt-3 space-y-1 text-[11px] text-slate-400">
                    <li className="flex items-center space-x-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Tracking-Kennung für jede Prüfungsarbeit</span>
                    </li>
                    <li className="flex items-center space-x-1.5">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Offizielle Warnhinweise in Metadaten & Fußzeile</span>
                    </li>
                  </ul>
                </div>

                {/* Hard Mode (Exam Shield) */}
                <div
                  onClick={() => setProtectionLevel("hard")}
                  className={`relative p-5 rounded-xl border cursor-pointer transition-all ${
                    protectionLevel === "hard"
                      ? "border-red-500/60 bg-red-950/20 shadow-lg shadow-red-950/40 ring-1 ring-red-500/50"
                      : "border-slate-800 bg-slate-950/40 hover:border-slate-700 hover:bg-slate-900/50"
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2.5 rounded-lg bg-red-900/40 text-red-400 border border-red-700/50">
                        <ShieldAlert className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-100 text-sm">
                          Strenger Modus (Hard / Exam Shield)
                        </h3>
                        <span className="text-[11px] text-red-400 font-mono">
                          Maximale KI-Sperre
                        </span>
                      </div>
                    </div>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        protectionLevel === "hard"
                          ? "border-red-400 bg-red-400"
                          : "border-slate-600"
                      }`}
                    >
                      {protectionLevel === "hard" && (
                        <div className="w-1.5 h-1.5 bg-slate-950 rounded-full" />
                      )}
                    </div>
                  </div>
                  <p className="mt-3 text-xs text-slate-400 leading-relaxed">
                    Sperrt die Textextraktion durch PDF-Rechteverschlüsselung. Fügt aggressive Anti-Scraping-Banner und Störzeichen ein, damit KIs das Dokument nicht verwerten können.
                  </p>
                  <ul className="mt-3 space-y-1 text-[11px] text-slate-400">
                    <li className="flex items-center space-x-1.5">
                      <Lock className="w-3.5 h-3.5 text-red-400" />
                      <span>Kopieren & KI-Textextraktion technisch gesperrt</span>
                    </li>
                    <li className="flex items-center space-x-1.5">
                      <EyeOff className="w-3.5 h-3.5 text-red-400" />
                      <span>Strenge Anti-Cheating-Bannermarkierung</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* 2. Drag & Drop File Upload Zone */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                2. Prüfungsdokument auswählen
              </label>

              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                  isDragging
                    ? "border-emerald-400 bg-emerald-500/10 scale-[1.01]"
                    : file
                    ? "border-emerald-500/50 bg-emerald-950/10"
                    : "border-slate-700 bg-slate-950/50 hover:border-slate-600 hover:bg-slate-900/40"
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  className="hidden"
                  accept=".pdf,.docx,.pptx,.txt"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileSelect(e.target.files[0]);
                    }
                  }}
                />

                {file ? (
                  <div className="flex flex-col items-center justify-center space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <FileCheck className="w-7 h-7" />
                    </div>
                    <div>
                      <p className="font-semibold text-slate-100 text-sm">{file.name}</p>
                      <p className="text-xs text-slate-400 font-mono mt-0.5">
                        {formatFileSize(file.size)} • {file.name.split(".").pop()?.toUpperCase()}
                      </p>
                    </div>
                    <span className="text-xs text-emerald-400 underline underline-offset-4">
                      Andere Datei auswählen
                    </span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-center text-slate-300">
                      <Upload className="w-7 h-7" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-200 text-sm">
                        Dokument hierher ziehen oder{" "}
                        <span className="text-emerald-400 underline underline-offset-2">
                          durchsuchen
                        </span>
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        Unterstützt: PDF, Word (.docx), PowerPoint (.pptx), Text (.txt) bis 10 MB
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-4 rounded-xl bg-red-950/40 border border-red-800/60 flex items-start space-x-3 text-red-200 text-xs">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold">Fehler bei der Validierung:</p>
                  <p className="text-red-300/90 mt-0.5">{errorMessage}</p>
                </div>
              </div>
            )}

            {/* Processing State & Progress Log */}
            {isProcessing && (
              <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-300">
                  <span className="font-mono flex items-center space-x-2">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                    <span>Dokument wird gegen KI-Auslesen abgesichert...</span>
                  </span>
                  <span className="text-emerald-400 font-mono font-bold">
                    {Math.round(((progressStage + 1) / stages.length) * 100)}%
                  </span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-emerald-500 to-cyan-400 h-full transition-all duration-300"
                    style={{
                      width: `${((progressStage + 1) / stages.length) * 100}%`,
                    }}
                  />
                </div>
                <p className="text-[11px] font-mono text-slate-400">
                  &gt; {stages[progressStage]}
                </p>
              </div>
            )}

            {/* Submit Action Button */}
            <div>
              <button
                type="button"
                disabled={!file || isProcessing}
                onClick={handleProcess}
                className={`w-full py-3.5 px-6 rounded-xl font-bold text-sm flex items-center justify-center space-x-2 transition-all ${
                  !file || isProcessing
                    ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                    : protectionLevel === "hard"
                    ? "bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white hover:brightness-110 shadow-lg shadow-red-950/50"
                    : "bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white hover:brightness-110 shadow-lg shadow-emerald-950/50"
                }`}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Schutzfilter werden angewandt...</span>
                  </>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>
                      {protectionLevel === "hard"
                        ? "Im strengen Prüfungsmodus schützen (Hard)"
                        : "Im einfachen Modus schützen (Simple)"}
                    </span>
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </>
                )}
              </button>
            </div>
          </div>
        ) : (
          /* Processing Success & Download View */
          <div className="py-6 text-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h2 className="text-xl font-bold text-white">
                Dokument erfolgreich abgesichert!
              </h2>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Das Dokument wurde mit der Schutzstufe{" "}
                <span className="font-semibold text-emerald-400 uppercase">
                  {protectionLevel === "hard" ? "Streng (Hard)" : "Einfach (Simple)"}
                </span>{" "}
                verarbeitet und ist vor unbefugtem KI-Scraping geschützt.
              </p>
            </div>

            {/* Document Info Card */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 max-w-lg mx-auto text-left">
              <div className="flex items-center space-x-3">
                <FileText className="w-8 h-8 text-emerald-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-200 truncate">
                    {result.filename}
                  </p>
                  <div className="flex items-center space-x-2 text-[11px] text-slate-400 font-mono mt-0.5">
                    <span>Größe: {formatFileSize(result.sizeBytes)}</span>
                    <span>•</span>
                    <span className="text-emerald-400">Verifiziert & versiegelt</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => triggerFileDownload(result.blob, result.filename)}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 text-white font-bold text-sm flex items-center justify-center space-x-2 shadow-lg shadow-emerald-950/40"
              >
                <Download className="w-4 h-4" />
                <span>Geschütztes Dokument herunterladen</span>
              </button>

              {onSwitchToSimulator && (
                <button
                  type="button"
                  onClick={onSwitchToSimulator}
                  className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center justify-center space-x-2"
                >
                  <ShieldAlert className="w-4 h-4 text-amber-400" />
                  <span>Im Prüfungsmodus-Simulator testen</span>
                </button>
              )}

              <button
                type="button"
                onClick={resetForm}
                className="w-full sm:w-auto px-4 py-3 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-400 text-xs"
              >
                Weiteres Dokument
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
