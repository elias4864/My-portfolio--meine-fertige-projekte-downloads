"use client";

import React, { useState } from "react";
import Navbar from "@/components/Navbar";
import DocumentUploader from "@/components/DocumentUploader";
import ExamLockdownSimulator from "@/components/ExamLockdownSimulator";
import AiDefenseVisualizer from "@/components/AiDefenseVisualizer";
import TrackingVerifier from "@/components/TrackingVerifier";
import { Shield, ShieldAlert, Cpu, CheckCircle2, Lock, FileSpreadsheet, Sparkles } from "lucide-react";

export default function Home() {
  const [activeTab, setActiveTab] = useState<string>("upload");

  return (
    <div className="min-h-screen flex flex-col bg-[#090d16] text-slate-100">
      {/* Top Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {activeTab === "upload" && (
          <DocumentUploader onSwitchToSimulator={() => setActiveTab("lockdown")} />
        )}

        {activeTab === "lockdown" && <ExamLockdownSimulator />}

        {activeTab === "ai-preview" && <AiDefenseVisualizer />}

        {activeTab === "verify" && <TrackingVerifier />}
      </main>

      {/* Quick Feature Highlights Bottom Section */}
      <section className="border-t border-slate-800/80 bg-slate-950/60 py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60 flex items-start space-x-3.5">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  2 Schutzstufen: Simple & Hard
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Vom einfachen Metadaten- & Fußzeilen-Wasserzeichen bis zur vollständigen KI-Textextraktionssperre für Klausuren.
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60 flex items-start space-x-3.5">
              <div className="p-2 rounded-lg bg-red-500/10 text-red-400 border border-red-500/20">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Prüfungs-Restriktion für Studenten
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  Kopierschutz, Zwischenablagesperre, Vollbildzwang und Echtzeit-Erkennung von Tab-Wechseln und KI-Nutzung.
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/60 flex items-start space-x-3.5">
              <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                <Cpu className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
                  FastAPI 8000 Backend
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  In-Memory Verarbeitung für PDF (PyPDF), Word (.docx), PowerPoint (.pptx) und Plaintext (.txt) mit Streaming-Download.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-[#060910] py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© 2026 Anti-AI DocShield • KI-Lernschutz Projekt für Universitäten & Schulen</p>
          <div className="flex items-center space-x-4 font-mono text-[11px]">
            <span>FastAPI: /document/process</span>
            <span>•</span>
            <span>Next.js 14 App Router</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
