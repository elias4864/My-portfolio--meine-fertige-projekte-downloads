import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Anti-AI DocShield | KI-Prüfungs- und Dokumentenschutz",
  description:
    "Next.js Frontend & FastAPI Backend zur Absicherung von Prüfungsdokumenten gegen KI-Scraping, unbefugtes Kopieren und Prüfungsbetrug.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de" className="dark">
      <body className="min-h-screen bg-[#090d16] text-slate-100 bg-grid-pattern antialiased selection:bg-emerald-500 selection:text-white">
        {children}
      </body>
    </html>
  );
}
