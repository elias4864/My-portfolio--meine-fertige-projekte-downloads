/**
 * API-Client für die Kommunikation mit dem Anti-AI DocShield FastAPI-Backend.
 */

const API_BASE_URL = process.env.NEXT_PUBLIC_BACKEND_URL || "http://127.0.0.1:8000";

export interface BackendConfig {
  allowed_extensions: string[];
  max_file_size_mb: number;
  protection_levels: {
    id: string;
    name: string;
    description: string;
  }[];
}

export interface BackendHealth {
  status: string;
  app: string;
  version: string;
}

export interface ProcessDocumentResult {
  blob: Blob;
  filename: string;
  sizeBytes: number;
}

/**
 * Ruft den Health-Status des Backends ab.
 */
export async function checkBackendHealth(): Promise<BackendHealth> {
  try {
    const response = await fetch(`${API_BASE_URL}/health`, {
      method: "GET",
      cache: "no-store",
    });
    if (!response.ok) {
      throw new Error(`Health Check fehlgeschlagen: HTTP ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    // Fallback falls direkter Aufruf geblockt ist, versuche über Next.js Rewrite
    try {
      const response = await fetch("/api/backend/health", { cache: "no-store" });
      if (response.ok) return await response.json();
    } catch {}
    throw error;
  }
}

/**
 * Ruft die Konfiguration des Backends ab.
 */
export async function getBackendConfig(): Promise<BackendConfig> {
  try {
    const response = await fetch(`${API_BASE_URL}/api/config`, {
      method: "GET",
      cache: "no-store",
    });
    if (!response.ok) {
      throw new Error(`Config Abruf fehlgeschlagen: HTTP ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    try {
      const response = await fetch("/api/backend/api/config", { cache: "no-store" });
      if (response.ok) return await response.json();
    } catch {}
    // Standard-Fallback falls Backend noch nicht läuft
    return {
      allowed_extensions: [".docx", ".pdf", ".pptx", ".txt"],
      max_file_size_mb: 10,
      protection_levels: [
        {
          id: "easy",
          name: "Einfacher Modus (Basic)",
          description: "Metadaten-Kennzeichnung, dezent sichtbare Hinweise und Tracking-ID.",
        },
        {
          id: "hard",
          name: "Strenger Prüfungsmodus (Hard / Exam Shield)",
          description: "Anti-AI-Verschlüsselung, Extraktionssperre gegen KI-Scraper und auffällige Prüfungs-Warnhinweise.",
        },
      ],
    };
  }
}

/**
 * Sendet ein Dokument zur Schutz-Verarbeitung an das FastAPI Backend.
 */
export async function processDocument(
  file: File,
  protectionLevel: "easy" | "hard"
): Promise<ProcessDocumentResult> {
  const formData = new FormData();
  formData.append("file", file);
  formData.append("stufe", protectionLevel);

  let response: Response;
  let targetUrl = `${API_BASE_URL}/document/process`;

  try {
    response = await fetch(targetUrl, {
      method: "POST",
      body: formData,
    });
  } catch (initialErr) {
    // Fallback zu lokalem Rewrite
    targetUrl = "/api/backend/document/process";
    response = await fetch(targetUrl, {
      method: "POST",
      body: formData,
    });
  }

  if (!response.ok) {
    let errorDetail = `Fehler ${response.status}`;
    try {
      const errJson = await response.json();
      if (errJson.detail) {
        errorDetail = errJson.detail;
      }
    } catch {
      const errText = await response.text();
      if (errText) errorDetail = errText;
    }
    throw new Error(errorDetail);
  }

  // Dateinamen aus dem Content-Disposition-Header extrahieren
  let filename = `protected_${file.name}`;
  const disposition = response.headers.get("Content-Disposition");
  if (disposition) {
    // 1. Suche nach RFC 5987 / UTF-8 Format: filename*=UTF-8''...
    const utf8Match = disposition.match(/filename\*=UTF-8''([^;]+)/i);
    if (utf8Match && utf8Match[1]) {
      try {
        filename = decodeURIComponent(utf8Match[1]);
      } catch {
        filename = utf8Match[1];
      }
    } else {
      // 2. Suche nach Standard: filename="..."
      const standardMatch = disposition.match(/filename="?([^";]+)"?/i);
      if (standardMatch && standardMatch[1]) {
        filename = standardMatch[1];
      }
    }
  }

  const blob = await response.blob();
  return {
    blob,
    filename,
    sizeBytes: blob.size,
  };
}

/**
 * Löst den Download einer Datei im Browser aus.
 */
export function triggerFileDownload(blob: Blob, filename: string): void {
  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  window.URL.revokeObjectURL(url);
}
