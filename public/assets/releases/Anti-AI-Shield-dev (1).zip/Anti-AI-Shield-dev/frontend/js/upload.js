// TODO: Upload-Formular anbinden: Multipart-POST an /document/process,
// Fehlerantworten anzeigen und die Ergebnisdatei mit dem Server-Dateinamen
// zum Download anbieten. Danach den Ablauf mit Frontend-/Browser-Tests prüfen.