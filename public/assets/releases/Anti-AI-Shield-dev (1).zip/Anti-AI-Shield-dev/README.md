# KI-Lernschutz

## Worum geht es?

KI-Lernschutz ist ein Studentenprojekt/Prototyp, mit dem Nutzer Dokumente
(derzeit PDF, DOCX, PPTX und TXT) hochladen und eine Schutzstufe auswählen
können. Das Backend gibt eine verarbeitete Datei mit sichtbaren Hinweisen
und/oder Metadaten zurück. Das soll auf die gewünschte Nutzung aufmerksam
machen; es verhindert nicht zuverlässig Kopieren, OCR oder KI-Auslesen.

Das Frontend-Verzeichnis ist derzeit noch leer. Die Backend-API kann unabhängig
davon getestet werden; ein vollständiger Test des Nutzerablaufs benötigt später
zusätzlich eine funktionierende Oberfläche.

## Aktueller Stand des Python-Backends

Die Python-Dateien sind nicht alle fertig. Einige liefern bereits einen funktionierenden
Prototyp; ein sichtbarer Hinweis oder Metadaten sind jedoch kein technischer Schutz vor
Kopieren oder KI-Verarbeitung.

| Datei/Bereich | Stand |
| --- | --- |
| `backend/config.py` | Zentrale Liste der unterstützten Endungen, 10-MB-Limit und Schutzstufen |
| `backend/main.py`, `backend/routes/process.py` | API mit `GET /health` und `POST /document/process` |
| `backend/utils/file_validation.py` | Endung, leere Datei und Größenlimit werden geprüft |
| `backend/services/identifier_service.py` | Kennung erstellen und Format prüfen; noch nicht in die Dokumentverarbeitung eingebunden |
| `backend/services/document_router.py` | Leitet PDF, DOCX, PPTX und TXT an den jeweiligen Dienst weiter |
| `backend/services/pdf_service.py` | PDF wird neu geschrieben und erhält Metadaten; kein sichtbarer Schutz |
| `backend/services/word_service.py` | DOCX erhält einen Hinweis in der Fußzeile; Schutzstufen und Formatierung sind noch nicht vereinheitlicht |
| `backend/services/powerpoint_service.py` | PPTX erhält einen Hinweis pro Folie; Basistest vorhanden, Fehlerfälle noch offen |
| `backend/services/txt_service.py` | Fügt einen Hinweis vor den Text; die Schutzstufen unterscheiden sich noch nicht |
| `backend/services/excel_service.py`, `backend/services/ppt_service.py` | Platzhalter; nicht über den Upload-Router freigeschaltet |
| `backend/services/protection_service.py` | Experimenteller Stand mit Import-Ausgaben; noch nicht in die Verarbeitung eingebunden |
| `backend/services/ocr_service.py` | Separater OCR-Prototyp, nicht in die Haupt-API eingebunden |
| `backend/utils/file_storage.py`, `backend/utils/cleanup.py` | Unfertig; `file_storage.py` hat noch einen Pylance-Fehler (`Path` nicht definiert). Derzeit nicht benötigt, weil die Verarbeitung im Arbeitsspeicher erfolgt |

### Was wurde angepasst?

- Die Upload-Prüfung verwendet jetzt dieselbe zentrale Konfiguration wie der Router. Das
  10-MB-Limit wird in Bytes geprüft; Groß-/Kleinschreibung der Dateiendung ist egal.
- Der Router und die API verwenden Paket-Imports statt zur Laufzeit `sys.path` zu verändern.
- Der Upload wird höchstens bis zum Größenlimit plus einem Byte eingelesen.
- Der PPTX-Parser verwendet die gültigen `python-pptx`-Attribute und Argumente für Textfelder.
- Die TXT-Verarbeitung gibt Bytes statt fehlerhafter Zeichenketten zurück.
- Nicht fertige Excel- und alte Office-Formate werden nicht als erfolgreich verarbeitet
  ausgegeben.
- Laufzeitabhängigkeiten der vorhandenen Python-Module sind in `requirements.txt` aufgeführt.

### Lokal starten

#### 1. Backend starten (FastAPI auf Port 8000)

```powershell
# Python-Abhängigkeiten installieren
python -m pip install -r requirements.txt

# FastAPI Backend starten
python -m uvicorn backend.main:app --reload --port 8000
```

Die API stellt folgende Endpunkte bereit:
- `GET /health` – Status der API
- `GET /api/config` – Unterstützte Formate und Schutzstufen
- `POST /document/process` – Datei-Upload & Anti-AI-Verarbeitung (`file` und `stufe`: `easy` oder `hard`)

#### 2. Frontend starten (Next.js 14 auf Port 3000)

```powershell
cd frontend
pnpm install # oder npm install
pnpm run dev # oder npm run dev
```

Die Benutzeroberfläche öffnet sich unter [http://localhost:3000](http://localhost:3000).

### Frontend-Funktionen (Anti-AI DocShield UI)

1. **Dokumentschutz-Modus (Upload & Processing)**:
   - Datei-Upload per Drag & Drop für PDF, DOCX, PPTX und TXT (bis 10 MB).
   - **Einfacher Modus (Simple / Easy)**: Fügt Urheberrechtshinweise in Fußzeilen ein, setzt Metadaten-Schutz und generiert eine individuelle Prüfungs-Tracking-ID (`AAS-YYYYMMDD-XXXXXXXX`).
   - **Strenger Prüfungsmodus (Hard / Exam Shield)**: Sperrt Textextraktion und Kopieren via PDF-Rechteverschlüsselung, platziert prominente Anti-Scraping-Banner und bettet Anti-LLM-Schutzmechanismen ein.
   - Echtzeit-Fortschrittsanzeige und direkter Download der geschützten Datei.

2. **Prüfungs-Restriktion für Studenten (Exam Lockdown Simulator)**:
   - Vollbild-Sperre für Klausursituationen.
   - Integrierte Zwischenablage- und Kopiersperre (blockiert Strg+C, Strg+X, Strg+U, F12 und Rechtsklick).
   - Tab-Wechsel- & Blur-Erkennung: Registriert und protokolliert jeden Versuch von Studenten, das Prüfungsfenster zu verlassen (z. B. um ChatGPT oder Claude zu konsultieren).
   - Prüfungs-Countdown-Timer und interaktives Klausurblatt zum Ausprobieren.

3. **KI-Abwehr-Demonstrator (Side-by-Side Visualizer)**:
   - Interaktiver Direktvergleich: Zeigt den Unterschied zwischen menschlicher Studentensicht (normale, lesbare Klausur) und KI-Scraper-Sicht (blockierte Extraktion, Injektionsfallen, Anti-Cheat-Warnungen).

4. **Tracking-ID & Dokument-Verifizierer**:
   - Prüfung von Prüfungs-Kennungen (`AAS-JJJJMMTT-XXXXXXXX` und `KLS-XXXXXX`) zur lückenlosen Echtheits- und Sitzplatz-Verifizierung.
