"""Tests für erlaubte Uploads und die Grenzen der Datei-Validierung."""
# TODO: Veraltete backend.file_storage-Imports entfernen und die Tests auf die
# tatsächlichen Module unter backend.utils ausrichten; pytest/unittest vereinheitlichen.
import pathlib
import sys
import unittest
import backend.file_storage as modul  # noqa: E402
from backend.file_storage import validate_upload  # n

import pytest

from backend.config import MAX_FILE_SIZE_BYTES
from backend.utils.file_validation import validate_upload


class ValidateUploadTests(unittest.TestCase):
    """Prüft Dateiendung, leere Inhalte und das konfigurierte Größenlimit."""

    def test_accepts_supported_extension_case_insensitively(self) -> None:
        self.assertTrue(validate_upload("referat.PDF", b"pdf bytes"))

    def test_accepts_file_at_size_limit(self) -> None:
        self.assertTrue(validate_upload("referat.txt", b"x" * MAX_FILE_SIZE_BYTES))

    def test_rejects_empty_file(self) -> None:
        with self.assertRaisesRegex(ValueError, "leer"):
            validate_upload("referat.pdf", b"")

    def test_rejects_file_over_size_limit(self) -> None:
        with self.assertRaisesRegex(ValueError, "10 MB"):
            validate_upload("referat.pdf", b"x" * (MAX_FILE_SIZE_BYTES + 1))

    def test_rejects_unsupported_extension(self) -> None:
        with self.assertRaisesRegex(ValueError, "nicht unterstützt"):
            validate_upload("referat.xlsx", b"excel bytes")


PROJEKT_ROOT = pathlib.Path(__file__).resolve().parent.parent
if str(PROJEKT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJEKT_ROOT))

# Passe den Modulnamen an, falls validate_upload in einer anderen Datei unter backend/ liegt



@pytest.fixture(autouse=True)
def mock_upload_config(monkeypatch):
    """Setzt definierte Testwerte für erlaubte Endungen und Maximalgröße."""
    monkeypatch.setattr(modul, "ALLOWED_EXTENSIONS", {".pdf", ".docx", ".txt"})
    monkeypatch.setattr(modul, "MAX_FILE_SIZE_MB", 5)

    monkeypatch.setattr(modul, "MAX_FILE_SIZE_BYTES", 5 * 1024 * 1024)


def test_validate_upload_erfolg():
    """Akzeptiert gültige Datei mit erlaubter Endung (auch Groß-/Kleinschreibung)."""
    assert validate_upload("bericht.pdf", b"Gueltiger PDF-Inhalt") is True
    assert validate_upload("DOKUMENT.DOCX", b"Gueltiger DOCX-Inhalt") is True


@pytest.mark.parametrize("ungueltiger_name", ["", None, 123])
def test_validate_upload_ungueltiger_dateiname(ungueltiger_name):
    """Wirft ValueError bei leerem oder nicht-string Dateinamen."""
    with pytest.raises(ValueError, match="kein gültiger Dateiname"):
        validate_upload(ungueltiger_name, b"Inhalt")


@pytest.mark.parametrize("ungueltiger_inhalt", [b"", None, "kein-bytes-objekt"])
def test_validate_upload_leerer_oder_ungueltiger_inhalt(ungueltiger_inhalt):
    """Wirft ValueError bei 0-Byte-Dateien oder falschem Datentyp."""
    with pytest.raises(ValueError, match="leer oder der Dateiinhalt ist ungültig"):
        validate_upload("test.pdf", ungueltiger_inhalt)


def test_validate_upload_zu_gross():
    """Wirft ValueError, sobald MAX_FILE_SIZE_BYTES um 1 Byte überschritten wird."""
    grenzwert = 5 * 1024 * 1024
    # Exakt am Limit -> muss klappen
    assert validate_upload("exakt.pdf", b"a" * grenzwert) is True

    # 1 Byte über dem Limit -> muss fehlschlagen
    with pytest.raises(ValueError, match="maximale Dateigröße beträgt 5 MB"):
        validate_upload("zu_gross.pdf", b"a" * (grenzwert + 1))


@pytest.mark.parametrize("verbotene_datei", ["virus.exe", "bild.png", "ohne_endung", ".hidden"])
def test_validate_upload_unerlaubte_endung(verbotene_datei):
    """Wirft ValueError bei nicht unterstützten Dateiendungen."""
    with pytest.raises(ValueError, match="wird nicht unterstützt"):
        validate_upload(verbotene_datei, b"Testdaten")


if __name__ == "__main__":
    unittest.main()
