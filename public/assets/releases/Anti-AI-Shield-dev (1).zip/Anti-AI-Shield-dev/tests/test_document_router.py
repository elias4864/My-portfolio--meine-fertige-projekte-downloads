"""Tests für Weiterleitung und Ausgabe der unterstützten Dokument-Services."""
import re
from datetime import datetime, timezone
from io import BytesIO
import unittest
from unittest.mock import patch

from docx import Document
from pptx import Presentation
from pypdf import PdfReader, PdfWriter

from backend.services.document_router import process_document, generate_tracking_id
from backend.services.pdf_service import process as process_pdf
from backend.services.powerpoint_service import process as process_powerpoint
from backend.services.txt_service import process as process_text
from backend.services.word_service import process as process_word


class ProcessDocumentTests(unittest.TestCase):
    """Prüft Router-Auswahl und grundlegende Ergebnisse der Format-Services."""

    # TODO: Die Router-Tests an die vereinheitlichte Service-Signatur anpassen
    # und HTTP-Tests für Upload, Fehlerfälle und Download ergänzen.
    # TODO: Sobald das Frontend umgesetzt ist, den Upload-/Download-Ablauf auch
    # über die Oberfläche testen; reine Backend-Tests brauchen kein Frontend.
    def test_dispatches_valid_document(self) -> None:
        with patch(
            "backend.services.document_router.pdf_service.process",
            return_value=(b"processed", "processed.pdf"),
        ) as process_pdf:
            result = process_document("report.PDF", b"pdf bytes", "easy")

        self.assertEqual(result, (b"processed", "processed.pdf"))
        process_pdf.assert_called_once_with(b"pdf bytes", "easy")

    def test_rejects_unknown_protection_level(self) -> None:
        with self.assertRaisesRegex(ValueError, "Ungültige Schutzstufe"):
            process_document("report.txt", b"text", "unknown")

    def test_text_service_returns_bytes_and_filename(self) -> None:
        self.assertEqual(
            process_text(b"example", "easy"),
            (b"example", "verarbeitetes_dokument.txt"),
        )

    def test_pdf_service_returns_readable_pdf(self) -> None:
        source = BytesIO()
        writer = PdfWriter()
        writer.add_blank_page(width=100, height=100)
        writer.write(source)

        result, filename = process_pdf(source.getvalue(), "easy")

        self.assertEqual(filename, "geschuetzt_stufe_easy.pdf")
        self.assertEqual(len(PdfReader(BytesIO(result)).pages), 1)

    def test_word_service_adds_footer(self) -> None:
        source = BytesIO()
        document = Document()
        document.add_paragraph("Testinhalt")
        document.save(source)

        result, _ = process_word(source.getvalue(), "hard")
        processed = Document(BytesIO(result))

        self.assertIn("Stufe: Hoch", processed.sections[0].footer.paragraphs[0].text)

    def test_powerpoint_service_adds_a_marking_to_each_slide(self) -> None:
        source = BytesIO()
        presentation = Presentation()
        presentation.slides.add_slide(presentation.slide_layouts[6])
        presentation.save(source)

        result, filename = process_powerpoint(source.getvalue(), "hard")
        processed = Presentation(BytesIO(result))

        self.assertEqual(filename, "protected_praesentation.pptx")
        self.assertEqual(len(processed.slides), 1)
        self.assertTrue(
            any(
                "[HIGH]" in shape.text
                for shape in processed.slides[0].shapes
                if shape.has_text_frame
            )
        )

    def test_generate_tracking_id_format(self):
        """Prüft, ob die Kennung dem Format AAS-JJJJMMTT-XXXXXXXX entspricht."""
        tracking_id = generate_tracking_id()

        assert isinstance(tracking_id, str)
        # Erwartet z. B. "AAS-20261116-A1B2C3D4" (8 Zeichen Hex in Großbuchstaben)
        assert re.fullmatch(r"^AAS-\d{8}-[0-9A-F]{8}$", tracking_id)

    def test_generate_tracking_id_enthält_aktuelles_utc_datum(self):
        """Prüft, ob das aktuelle UTC-Datum korrekt in der ID steht."""
        heute_utc = datetime.now(timezone.utc).strftime("%Y%m%d")
        tracking_id = generate_tracking_id()

        teile = tracking_id.split("-")
        assert len(teile) == 3
        assert teile[0] == "AAS"
        assert teile[1] == heute_utc
        assert len(teile[2]) == 8

    def test_generate_tracking_id_ist_eindeutig(self):
        """Prüft, ob bei mehrfachem Aufruf unterschiedliche IDs erzeugt werden."""
        ids = {generate_tracking_id() for _ in range(100)}
        assert len(ids) == 100

    def test_generate_tracking_id_deterministisch_mit_mock(self):
        """Prüft mit festem Datum und fester UUID das exakte Ergebnis."""
        fester_zeitpunkt = datetime(2026, 11, 16, 12, 0, 0, tzinfo=timezone.utc)

        with (
            patch("backend.services.document_service.datetime") as mock_datetime,
            patch("backend.services.document_service.uuid.uuid4") as mock_uuid,
        ):
            mock_datetime.now.return_value = fester_zeitpunkt
            mock_uuid.return_value.hex = "abcdef1234567890"

            ergebnis = generate_tracking_id()
            assert ergebnis == "AAS-20261116-ABCDEF12"


if __name__ == "__main__":
    unittest.main()


