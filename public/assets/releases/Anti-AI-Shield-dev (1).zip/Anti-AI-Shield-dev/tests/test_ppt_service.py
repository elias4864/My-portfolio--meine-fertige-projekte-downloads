import pytest
from unittest.mock import patch

# Importiere deine Funktion hier (passe den Pfad an, falls sie in einem anderen Modul liegt)
# from dein_modul import process



def test_process_success_with_extension():
    """Testet die erfolgreiche Verarbeitung einer PowerPoint-Datei mit Dateiendung."""
    mock_content = b"original pptx content bytes"
    mock_processed_content = b"protected pptx content bytes"
    filename = "praesentation.pptx"
    stufe = "hoch"

    # Mocking des externen powerpoint_service
    with patch("powerpoint_service.process", return_value=mock_processed_content) as mock_service:
        content, new_filename = process(mock_content, stufe, filename)

        # Überprüfungen
        mock_service.assert_called_once_with(mock_content, stufe)
        assert content == mock_processed_content
        assert new_filename == "protected_praesentation.pptx"


def test_process_success_without_extension():
    """Testet das Verhalten, wenn der Dateiname keine Endung besitzt."""
    mock_content = b"some bytes"
    mock_processed_content = b"processed bytes"
    filename = "praesentation_ohne_endung"
    stufe = "mittel"

    with patch("powerpoint_service.process", return_value=mock_processed_content) as mock_service:
        content, new_filename = process(mock_content, stufe, filename)

        mock_service.assert_called_once_with(mock_content, stufe)
        assert content == mock_processed_content
        assert new_filename == "protected_presentation.pptx"



def test_process_service_exception_handling():
    """Testet, ob Fehler vom powerpoint_service sauber als RuntimeError gewrappt werden."""
    mock_content = b"some bytes"
    filename = "test.pptx"
    stufe = "schwach"

    # Simuliere einen Fehler im Service
    with patch("powerpoint_service.process", side_effect=ValueError("Interner Verarbeitungsfehler")):
        with pytest.raises(RuntimeError) as exc_info:
            process(mock_content, stufe, filename)

        # Prüfen, ob die Fehlermeldung korrekt formatiert wurde
        assert "Fehler bei der PowerPoint-Verarbeitung (Anti-AI-Shield)" in str(exc_info.value)
        assert "Interner Verarbeitungsfehler" in str(exc_info.value)