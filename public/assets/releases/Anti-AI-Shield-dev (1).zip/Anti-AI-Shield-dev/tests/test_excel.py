import io
import unittest
import pandas as pd

# Passe den Modulnamen an, falls dein Code z. B. in `excel_processor.py` liegt.
import excel_processor


def _erstelle_xlsx_bytes(blaetter: dict[str, pd.DataFrame]) -> bytes:
    """Hilfsfunktion: Erzeugt gültige XLSX-Bytes aus einem Dict von DataFrames."""
    puffer = io.BytesIO()
    with pd.ExcelWriter(puffer, engine="openpyxl") as writer:
        for sheet_name, df in blaetter.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)
    puffer.seek(0)
    return puffer.getvalue()


class TestExcelUploadProcess(unittest.TestCase):
    def setUp(self):
        self.sample_xlsx = _erstelle_xlsx_bytes(
            {
                "Tabelle1": pd.DataFrame(
                    {"SpalteA": [1, 2], "SpalteB": ["Alpha", "Beta"]}
                ),
                "Tabelle2": pd.DataFrame({"Wert": [10.5, 20.0]}),
            }
        )

    def test_valid_levels_return_xlsx_bytes_and_filename(self):
        for stufe in ["basic", "medium", "high"]:
            with self.subTest(stufe=stufe):
                ergebnis_bytes, dateiname = excel_processor.process(
                    self.sample_xlsx, stufe
                )

                self.assertIsInstance(ergebnis_bytes, bytes)
                self.assertGreater(len(ergebnis_bytes), 0)
                self.assertEqual(dateiname, "protected_dokument.xlsx")

                # Prüfen, ob die Ausgabe wieder als gültige Excel-Datei lesbar ist
                gelesen = pd.read_excel(
                    io.BytesIO(ergebnis_bytes), sheet_name=None, engine="openpyxl"
                )
                self.assertEqual(list(gelesen.keys()), ["Tabelle1", "Tabelle2"])
                self.assertEqual(gelesen["Tabelle1"]["SpalteB"].tolist(), ["Alpha", "Beta"])

    def test_invalid_level_raises_value_error(self):
        for ungueltige_stufe in ["invalid", "BASIC", "", None]:
            with self.subTest(stufe=ungueltige_stufe):
                with self.assertRaises(ValueError) as ctx:
                    excel_processor.process(self.sample_xlsx, ungueltige_stufe)
                self.assertIn("Unbekannte Schutzstufe", str(ctx.exception))

    def test_empty_or_non_bytes_content_raises_value_error(self):
        for ungueltiger_inhalt in [b"", None, "kein-bytes", 123]:
            with self.subTest(inhalt=ungueltiger_inhalt):
                with self.assertRaises(ValueError) as ctx:
                    excel_processor.process(ungueltiger_inhalt, "basic")
                self.assertIn("leer oder ungültig", str(ctx.exception))

    def test_corrupted_excel_bytes_raises_value_error(self):
        kaputte_daten = b"dies ist keine gueltige excel-datei"
        with self.assertRaises(ValueError) as ctx:
            excel_processor.process(kaputte_daten, "basic")
        self.assertIn("Fehler bei der Excel-Verarbeitung", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()