import unittest

# Passe den Modulnamen an, falls dein Code z. B. in `protection_service.py` liegt.
import protection_service


class TestProtectionLevels(unittest.TestCase):
    def setUp(self):
        """Stellt LEVEL_DESCRIPTIONS bereit, falls im Modul nur protection_levels definiert ist."""
        self._added_level_descriptions = False
        if not hasattr(protection_service, "LEVEL_DESCRIPTIONS"):
            setattr(
                protection_service,
                "LEVEL_DESCRIPTIONS",
                protection_service.protection_levels,
            )
            self._added_level_descriptions = True

    def tearDown(self):
        """Räumt testweise gesetzte Attribute wieder sauber auf."""
        if self._added_level_descriptions and hasattr(
            protection_service, "LEVEL_DESCRIPTIONS"
        ):
            delattr(protection_service, "LEVEL_DESCRIPTIONS")

    def test_is_valid_level_accepts_allowed_levels(self):
        for level in ["easy", "hard"]:
            with self.subTest(level=level):
                self.assertTrue(protection_service.is_valid_level(level))

    def test_is_valid_level_rejects_invalid_levels(self):
        for invalid_level in ["medium", "EASY", "", None, 123]:
            with self.subTest(invalid_level=invalid_level):
                self.assertFalse(protection_service.is_valid_level(invalid_level))

    def test_validate_difficulty_level_returns_valid_level(self):
        self.assertEqual(protection_service.validate_difficulty_level("easy"), "easy")
        self.assertEqual(protection_service.validate_difficulty_level("hard"), "hard")

    def test_validate_difficulty_level_raises_value_error(self):
        for invalid_level in ["extreme", "invalid", ""]:
            with self.subTest(invalid_level=invalid_level):
                with self.assertRaises(ValueError) as ctx:
                    protection_service.validate_difficulty_level(invalid_level)
                self.assertIn("Ungültige Schutzstufe", str(ctx.exception))

    def test_valid_selected_level(self):
        self.assertTrue(protection_service.valid_selected_level("easy"))
        self.assertTrue(protection_service.valid_selected_level("hard"))
        self.assertFalse(protection_service.valid_selected_level("unknown"))

    def test_create_marking_without_subject(self):
        result_easy = protection_service.create_marking("KLS-A1B2C3", "easy")
        result_hard = protection_service.create_marking("KLS-A1B2C3", "hard")

        self.assertIn("KLS-A1B2C3", result_easy)
        self.assertIn("Einfache Erkennung", result_easy)
        self.assertIn("KLS-A1B2C3", result_hard)
        self.assertIn("Erweiterte(Eingeschränkte) Erkennung", result_hard)

    def test_create_marking_with_subject_adds_three_letter_code(self):
        result = protection_service.create_marking(
            "KLS-123456", "hard", subject="Biologie"
        )

        self.assertIn("KLS-123456-BIO", result)

        self.assertIn("Fusszeile: Kennung KLS-123456-BIO", result)


    def test_create_marking_rejects_empty_identifier(self):
        for empty_id in ["", "   ", None]:
            with self.subTest(empty_id=empty_id):
                with self.assertRaises(ValueError):
                    protection_service.create_marking(empty_id, "easy")

    def test_create_marking_rejects_invalid_level(self):
        with self.assertRaises(ValueError):
            protection_service.create_marking("KLS-A1B2C3", "super-hard")


if __name__ == "__main__":
    unittest.main()