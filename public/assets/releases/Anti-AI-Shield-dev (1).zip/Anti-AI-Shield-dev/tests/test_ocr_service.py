import io
import sys
import types
import importlib
import pytest
from fastapi.testclient import TestClient
from PIL import Image


def create_png_bytes(size=(32, 32), color=(255, 255, 255)) -> bytes:
    buf = io.BytesIO()
    Image.new("RGB", size, color).save(buf, format="PNG")
    return buf.getvalue()


@pytest.fixture
def ocr_client(monkeypatch):
    """Lädt das FastAPI-Modul mit gemocktem pytesseract und pdf2image."""
    module_name = "ocr_service"  # Dateiname ohne .py anpassen

    fake_pytesseract = types.SimpleNamespace(
        image_to_string=lambda img, lang="deu": "Standard OCR Text"
    )
    fake_pdf2image = types.SimpleNamespace(
        convert_from_bytes=lambda pdf_bytes: [Image.new("RGB", (20, 20), (255, 255, 255))]
    )

    monkeypatch.setitem(sys.modules, "pytesseract", fake_pytesseract)
    monkeypatch.setitem(sys.modules, "pdf2image", fake_pdf2image)

    if module_name in sys.modules:
        del sys.modules[module_name]
    mod = importlib.import_module(module_name)
    monkeypatch.setattr(mod, "pytesseract", fake_pytesseract, raising=False)
    monkeypatch.setattr(mod, "convert_from_bytes", fake_pdf2image.convert_from_bytes, raising=False)

    client = TestClient(mod.app)
    return client, mod, fake_pytesseract, fake_pdf2image


def test_ocr_upload_png_kennung_gefunden(ocr_client):
    client, _, fake_pytesseract, _ = ocr_client
    fake_pytesseract.image_to_string = lambda img, lang="deu": "Dokument mit Kennung kls-a1b2c3 geprüft."

    png_data = create_png_bytes()
    response = client.post(
        "/ocr-upload/",
        files={"file": ("scan.png", png_data, "image/png")},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["dateiname"] == "scan.png"
    assert body["dateityp"] == "image/png"
    assert body["status"] == "gefunden"
    assert body["erkannte_kennung"].upper() == "KLS-A1B2C3"
    assert "kls-a1b2c3" in body["erkanntes_text_ergebnis"]


def test_ocr_upload_png_kennung_nicht_gefunden(ocr_client):
    client, _, fake_pytesseract, _ = ocr_client
    fake_pytesseract.image_to_string = lambda img, lang="deu": "Text ohne gültige Kennung."

    response = client.post(
        "/ocr-upload/",
        files={"file": ("notiz.png", create_png_bytes(), "image/png")},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "nicht_gefunden"
    assert body["erkannte_kennung"] is None


def test_ocr_upload_unlesbar_bei_leerem_ocr(ocr_client):
    client, _, fake_pytesseract, _ = ocr_client
    fake_pytesseract.image_to_string = lambda img, lang="deu": "   \n  "

    response = client.post(
        "/ocr-upload/",
        files={"file": ("leer.png", create_png_bytes(), "image/png")},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "unlesbar"
    assert body["erkannte_kennung"] is None
    assert body["erkanntes_text_ergebnis"] == ""
    assert "meldung" in body


def test_ocr_upload_pdf_mehrseitig(ocr_client):
    client, _, fake_pytesseract, fake_pdf2image = ocr_client
    fake_pdf2image.convert_from_bytes = lambda pdf_bytes: ["page1", "page2"]

    texts = iter(["Seite eins ohne Treffer", "Seite zwei mit KLS-99X8Y7"])
    fake_pytesseract.image_to_string = lambda img, lang="deu": next(texts)

    response = client.post(
        "/ocr-upload/",
        files={"file": ("bericht.pdf", b"%PDF-1.4 fake content", "application/pdf")},
    )

    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "gefunden"
    assert body["erkannte_kennung"] == "KLS-99X8Y7"
    assert "--- Seite 1 ---" in body["erkanntes_text_ergebnis"]
    assert "--- Seite 2 ---" in body["erkanntes_text_ergebnis"]


def test_ocr_upload_ungueltiger_dateityp(ocr_client):
    client, *_ = ocr_client

    response = client.post(
        "/ocr-upload/",
        files={"file": ("script.exe", b"MZ...", "application/x-msdownload")},
    )

    assert response.status_code == 400
    assert "wird nicht unterstützt" in response.json()["detail"]


def test_ocr_upload_datei_zu_gross(ocr_client):
    client, mod, *_ = ocr_client
    oversized_bytes = b"x" * (mod.MAX_FILE_SIZE + 1)

    response = client.post(
        "/ocr-upload/",
        files={"file": ("gross.png", oversized_bytes, "image/png")},
    )

    assert response.status_code == 400
    assert "5 MB" in response.json()["detail"]


def test_ocr_upload_unerwarteter_fehler_gibt_500(ocr_client):
    client, _, fake_pytesseract, _ = ocr_client

    def boom(img, lang="deu"):
        raise RuntimeError("Tesseract abgestürzt")

    fake_pytesseract.image_to_string = boom

    response = client.post(
        "/ocr-upload/",
        files={"file": ("fehler.png", create_png_bytes(), "image/png")},
    )

    assert response.status_code == 500
    assert "Fehler bei der OCR-Verarbeitung" in response.json()["detail"]