import io
import pytest
from docx import Document
from docx.shared import Pt, RGBColor
# Passe den Importpfad an deine Ordnerstruktur an (z. B. backend.services.word_service)
from backend.services.word_service import process


def test_process_ueberschreibt_bestehende_fusszeile():
    """Prüft, ob eine bereits vorhandene Fußzeile sauber ersetzt und nicht angehängt wird."""
    doc = Document()
    doc.sections[0].footer.paragraphs[0].text = "Alter vertraulicher Text"
    buf = io.BytesIO()
    doc.save(buf)

    ergebnis_bytes, _ = process(buf.getvalue(), stufe="hard")
    result_doc = Document(io.BytesIO(ergebnis_bytes))
    footer_text = result_doc.sections[0].footer.paragraphs[0].text

    assert "Alter vertraulicher Text" not in footer_text
    assert footer_text == "Anti-AI-Shield [HIGH]: Scraping & automatisches Auslesen strengstens untersagt."


def test_process_erste_seite_anders():
    """Prüft, ob der Hinweis auch auf Seite 1 erscheint, wenn 'Erste Seite anders' aktiv ist."""
    doc = Document()
    doc.sections[0].different_first_page_header_footer = True
    buf = io.BytesIO()
    doc.save(buf)

    ergebnis_bytes, _ = process(buf.getvalue(), stufe="hard")
    result_doc = Document(io.BytesIO(ergebnis_bytes))

    assert "[HIGH]" in result_doc.sections[0].first_page_footer.paragraphs[0].text
    assert "[HIGH]" in result_doc.sections[0].footer.paragraphs[0].text


def test_process_leere_bytes_wirft_value_error():
    """Prüft das Verhalten bei einer komplett leeren 0-Byte-Datei."""
    with pytest.raises(ValueError, match="Fehler bei der Verarbeitung der Word-Datei"):
        process(b"", stufe="easy")