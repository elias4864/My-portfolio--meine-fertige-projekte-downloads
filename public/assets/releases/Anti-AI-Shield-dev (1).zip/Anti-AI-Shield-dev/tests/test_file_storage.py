import pathlib
import sys
from pathlib import process_temp_storage
# TODO: process_temp_storage aus backend.utils.file_storage importieren und
# prüfen, ob diese Platzhalterfunktion überhaupt noch Teil des Projekts sein soll.

import pytest


def test_process_temp_storage_erfolg():
    """Prüft den Standardfall: Bytes und neuer Dateiname werden korrekt zurückgegeben."""
    dateiname = "elias.docx"
    inhalt = b"Dies ist eine Testnachricht"

    ergebnis_bytes, neuer_name = process_temp_storage(dateiname, inhalt, stufe="hoch")

    assert neuer_name == "Protected_elias.docx"
    assert ergebnis_bytes == inhalt
    assert isinstance(ergebnis_bytes, bytes)


def test_process_temp_storage_path_traversal_schutz():
    """Prüft, ob gefährliche Pfadangaben im Dateinamen sicher bereinigt werden."""
    boeser_dateiname = "../../geheim/angriff.pdf"
    inhalt = b"PDF-Testdaten"

    ergebnis_bytes, neuer_name = process_temp_storage(
        boeser_dateiname, inhalt, stufe="mittel"
    )

    assert neuer_name == "Protected_angriff.pdf"
    assert ergebnis_bytes == inhalt


@pytest.mark.parametrize("ungueltiger_name", ["", "/", "//"])
def test_process_temp_storage_ungueltiger_dateiname(ungueltiger_name):
    """Prüft, ob bei leeren oder ungültigen Dateinamen ein ValueError geworfen wird."""
    with pytest.raises(ValueError, match="Ungültiger Dateiname"):
        process_temp_storage(ungueltiger_name, b"daten", stufe="niedrig")


def test_process_temp_storage_leere_datei():
    """Prüft, ob auch eine 0-Byte-Datei ohne Fehler verarbeitet wird."""
    ergebnis_bytes, neuer_name = process_temp_storage("leer.txt", b"", stufe="hoch")

    assert neuer_name == "Protected_leer.txt"
    assert ergebnis_bytes == b""


def test_process_temp_storage_temp_ordner_wird_geloescht(capsys):
    """Prüft über die Konsolenausgabe, ob der temporäre Pfad nach Ablauf nicht mehr existiert."""
    import pathlib

    process_temp_storage("cleanup_test.docx", b"123", stufe="hoch")
    ausgabe = capsys.readouterr().out

    # Extrahiert den gespeicherten Pfad aus der Print-Ausgabe
    for zeile in ausgabe.splitlines():
        if "Verarbeitete Datei temporär gespeichert unter:" in zeile:
            pfad_str = zeile.split("unter: ")[1].strip()
            assert not pathlib.Path(pfad_str).exists()