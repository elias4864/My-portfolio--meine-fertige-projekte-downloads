import io
from pypdf import PdfReader, PdfWriter

# Einheitliche Schutzstufen-Konfiguration (kompatibel mit Word & PPTX)
SCHUTZSTUFEN = {
    "high": {
        "aliases": {"hard", "hoch", "high", "3"},
        "text": "Anti-AI-Shield [HIGH]: Scraping & automatisches Auslesen strengstens untersagt.",
        "level": 3,
    },
    "medium": {
        "aliases": {"medium", "mittel", "2"},
        "text": "Anti-AI-Shield [MEDIUM]: Urheberrechtlich geschützter Inhalt.",
        "level": 2,
    },
    "basic": {
        "aliases": {"basic", "easy", "niedrig", "1"},
        "text": "Anti-AI-Shield [BASIC]: Hinweis aktiv.",
        "level": 1,
    },
}


def get_schutzstufe_config(stufe: str) -> dict:
    """Normalisiert die Eingabe und liefert die einheitliche Schutzstufen-Konfiguration."""
    stufe_clean = str(stufe).strip().lower()
    for config in SCHUTZSTUFEN.values():
        if stufe_clean in config["aliases"]:
            return config
    return SCHUTZSTUFEN["basic"]


def process(inhalt: bytes, stufe: str) -> tuple[bytes, str]:
    """Zentrale Schnittstelle für die PDF-Verarbeitung, welcher die Datei direkt an den process_pdf-Service weiterleitet."""
    return process_pdf(inhalt, stufe)


def process_pdf(inhalt: bytes, stufe: str) -> tuple[bytes, str]:
    """Kopiert PDF-Seiten, setzt Stufen-Metadaten, wendet je nach Schutzstufe

    Einschränkungen an und gibt Bytes sowie Dateinamen zurück.
    """
    try:
        # 1. PDF aus Bytes im Arbeitsspeicher öffnen (ohne temporäre Datei auf Festplatte)
        input_stream = io.BytesIO(inhalt)
        reader = PdfReader(input_stream)
        writer = PdfWriter()

        # Prüfen, ob die PDF beschädigt ist oder keine Seiten enthält
        if len(reader.pages) == 0:
            raise ValueError("Die PDF-Datei enthält keine Seiten oder ist leer.")

        # Schutzstufen-Konfiguration ermitteln (Basic, Medium oder High)
        config = get_schutzstufe_config(stufe)
        stufe_name = "high" if config["level"] == 3 else ("medium" if config["level"] == 2 else "basic")

        # 2. Seiten nacheinander kopieren
        for page in reader.pages:
            writer.add_page(page)

        # 3. Metadaten je nach Stufe ansetzen
        writer.add_metadata({
            "/Title": f"Anti-AI-Shield Protected [{stufe_name.upper()}]",
            "/Subject": config["text"],
            "/Producer": "Anti-AI-Shield Engine"
        })

        # 4. Je nach Stufe Einschränkungen hinzufügen (z.B. im High-Modus Textkopierschutz via Verschlüsselung)
        if config["level"] == 3:
            # Im High-Mode wird die PDF mit einem zufälligen Passwort verschlüsselt
            # und das Extrahieren von Text/Inhalten für KI-Scraper unterbunden.
            import secrets
            owner_pwd = secrets.token_hex(16)
            # Berechtigungs-Flag: Drucken erlaubt, aber Textextraktion/Kopieren deaktiviert
            writer.encrypt(
                user_pwd="",
                owner_pwd=owner_pwd,
                permissions_flag=0b000001000000  # Einschränkung für Textextraktion
            )

        # 5. Die bearbeitete PDF wieder in Bytes umwandeln
        output_stream = io.BytesIO()
        writer.write(output_stream)
        ergebnis_bytes = output_stream.getvalue()

        # 6. Neuen Dateinamen generieren
        neuer_dateiname = f"geschuetzt_{stufe_name}.pdf"
        return ergebnis_bytes, neuer_dateiname

    except Exception as e:
        # Fehler bei kaputten oder passwortgeschützten PDFs abfangen
        raise ValueError(f"Fehler beim Verarbeiten der PDF-Datei: {e}") from e


# ==========================================
# PYTEST UNIT-TESTS
# ==========================================

import pytest


@pytest.fixture
def sample_pdf_bytes():
    """Erstellt eine minimale, gültige Test-PDF im Arbeitsspeicher."""
    writer = PdfWriter()
    # Füge eine leere Seite hinzu (oder mit minimalem Text via ReportLab o.ä., hier reicht PdfWriter-Export)
    writer.add_blank_page(width=72, height=72)
    output_stream = io.BytesIO()
    writer.write(output_stream)
    return output_stream.getvalue()


def test_get_schutzstufe_config():
    """Testet die Normalisierung und Fallback-Logik der Schutzstufen."""
    assert get_schutzstufe_config("high")["level"] == 3
    assert get_schutzstufe_config("HOCH")["level"] == 3
    assert get_schutzstufe_config("3")["level"] == 3
    assert get_schutzstufe_config("mittel")["level"] == 2
    assert get_schutzstufe_config("unknown_fallback")["level"] == 1


def test_process_pdf_basic(sample_pdf_bytes):
    """Testet die Verarbeitung auf Stufe 'basic' (Metadaten & Dateiname)."""
    out_bytes, filename = process(sample_pdf_bytes, "basic")

    assert filename == "geschuetzt_basic.pdf"
    assert isinstance(out_bytes, bytes)

    # Metadaten verifizieren
    reader = PdfReader(io.BytesIO(out_bytes))
    meta = reader.metadata
    assert meta.get("/Title") == "Anti-AI-Shield Protected [BASIC]"
    assert meta.get("/Subject") == SCHUTZSTUFEN["basic"]["text"]


def test_process_pdf_medium(sample_pdf_bytes):
    """Testet die Verarbeitung auf Stufe 'medium'."""
    out_bytes, filename = process(sample_pdf_bytes, "medium")

    assert filename == "geschuetzt_medium.pdf"
    reader = PdfReader(io.BytesIO(out_bytes))
    meta = reader.metadata
    assert meta.get("/Title") == "Anti-AI-Shield Protected [MEDIUM]"
    assert meta.get("/Subject") == SCHUTZSTUFEN["medium"]["text"]


def test_process_pdf_high_encryption(sample_pdf_bytes):
    """Testet den High-Modus inklusive Verschlüsselung und Einschränkung."""
    out_bytes, filename = process(sample_pdf_bytes, "high")

    assert filename == "geschuetzt_high.pdf"

    # Prüfen, ob das Ergebnis verschlüsselt ist
    reader = PdfReader(io.BytesIO(out_bytes))
    assert reader.is_encrypted is True


def test_process_pdf_invalid_input():
    """Testet das Werfen eines Status-Errors 422  bei einer  beschädigten oder leeren Daten."""
    with pytest.raises(ValueError, match="Fehler beim Verarbeiten"):
        process(b"keine_gueltige_pdf_daten", "basic")

    with pytest.raises(ValueError, match="Die PDF-Datei enthält keine Seiten"):
        # Erstelle leeren Stream ohne Seiten
        empty_writer = PdfWriter()
        empty_stream = io.BytesIO()
        empty_writer.write(empty_stream)
        process(empty_stream.getvalue(), "basic")