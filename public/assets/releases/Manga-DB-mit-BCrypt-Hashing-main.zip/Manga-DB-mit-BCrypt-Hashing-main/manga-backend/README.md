Backend- Login Hashing mit Bcrypt
