package com.wiss.quizbackend.service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtService {



    @Value("${jwt.secret}")
    private String secretKey;

    /**
     * Token Gültigkeit in Millisekunden (24h = 86400000ms).
     */
    @Value("${jwt.expiration}")
    private long expirationTime;

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }


    public String extractRole(String token) {
        return extractClaim(token, claims -> claims.get("role", String.class));
    }


    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }


    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }


    public Boolean validateToken(String token, String username) {
        final String extractedUsername = extractUsername(token);
        return (extractedUsername.equals(username) &&
                !isTokenExpired(token));
    }


    private Key getSigningKey() {
        byte[] keyBytes = secretKey.getBytes();
        return Keys.hmacShaKeyFor(keyBytes);
    }



    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSigningKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public String generateToken(String username, String role) {
        // 1. Claims Map erstellen (Payload)
        Map<String, Object> claims = new HashMap<>();
        claims.put("role", role);  // Custom Claim für Rolle

        // 2. Token bauen
        return Jwts.builder()
                .setClaims(claims)     // Custom Claims
                .setSubject(username)  // Standard Claim (Username)
                .setIssuedAt(new Date(System.currentTimeMillis()))  // Jetzt
                .setExpiration(
                        new Date(System.currentTimeMillis()
                                + expirationTime))  // +24h
                .signWith(getSigningKey(),
                        SignatureAlgorithm.HS256)  // Signieren
                .compact();  // Zu String konvertieren
    }


}
