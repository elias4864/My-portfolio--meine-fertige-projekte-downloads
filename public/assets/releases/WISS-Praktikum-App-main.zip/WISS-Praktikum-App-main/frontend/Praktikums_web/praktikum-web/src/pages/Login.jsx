import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";

function Login({ onLoginSuccess }) {
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        username: "",
        password: "",
        rememberMe: false,
    });

    const [error, setError] = useState("");
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        if (!formData.username.trim() || !formData.password) {
            setError("Bitte alle Felder ausfüllen.");
            return;
        }

        try {
            setLoading(true);

            const res = await fetch("/api/auth/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    usernameOrEmail: formData.username.trim(),
                    password: formData.password,
                }),
            });

            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.error || "Login fehlgeschlagen");
            }

            const storage = formData.rememberMe ? localStorage : sessionStorage;
            storage.setItem("token", data.token);
            storage.setItem("role", data.role);

            // Navbar über Login informieren
            if (onLoginSuccess) onLoginSuccess(data);

            navigate("/");
        } catch (err) {
            setError(err.message || "Login fehlgeschlagen.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="lg-page">


            <div className="lg-card">
                <h1 className="lg-title">Login</h1>
                <p className="lg-sub">Melde dich an, um fortzufahren</p>

                {error && <div className="lg-error" role="alert">{error}</div>}

                <form onSubmit={handleSubmit}>
                    <div className="lg-field">
                        <input
                            className="lg-input"
                            name="username"
                            type="text"
                            placeholder="Username"
                            autoComplete="username"
                            value={formData.username}
                            onChange={handleChange}
                        />
                    </div>

                    <div className="lg-field">
                        <input
                            className="lg-input"
                            name="password"
                            type={showPassword ? "text" : "password"}
                            placeholder="Passwort"
                            autoComplete="current-password"
                            value={formData.password}
                            onChange={handleChange}
                            style={{ paddingRight: "70px" }}
                        />
                        <button
                            type="button"
                            className="lg-toggle"
                            onClick={() => setShowPassword((prev) => !prev)}
                            aria-label={showPassword ? "Passwort verbergen" : "Passwort anzeigen"}
                        >
                            {showPassword ? "Hide" : "Show"}
                        </button>
                    </div>

                    <label className="lg-remember">
                        <input
                            type="checkbox"
                            name="rememberMe"
                            checked={formData.rememberMe}
                            onChange={handleChange}
                        />
                        Remember me
                    </label>

                    <button type="submit" className="lg-btn" disabled={loading}>
                        {loading ? "Wird geladen..." : "Login"}
                    </button>
                </form>

                <div className="lg-footer">
                    Passwort vergessen? <Link to="/forgotpassword">Passwort vergessen</Link>
                </div>
                <div className="lg-footer">
                    Noch kein Konto? <Link to="/register">Registrieren</Link>
                </div>
            </div>
        </div>
    );
}

export default Login;