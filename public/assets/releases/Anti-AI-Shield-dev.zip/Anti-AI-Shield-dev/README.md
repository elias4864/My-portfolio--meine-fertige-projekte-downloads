# KI-Lernschutz

## Aktueller Stand des Python-Backends

Die Python-Dateien sind nicht alle fertig. Einige liefern bereits einen funktionierenden
Prototyp; ein sichtbarer Hinweis oder Metadaten sind jedoch kein technischer Schutz vor
Kopieren oder KI-Verarbeitung.

| Datei/Bereich | Stand |
| --- | --- |
| `backend/config.py` | Zentrale Liste der unterstützten Endungen, 10-MB-Limit und Schutzstufen |
| `backend/main.py`, `backend/routes/process.py` | API mit `GET /health` und `POST /document/process` |
| `backend/utils/file_validation.py` | Endung, leere Datei und Größenlimit werden geprüft |
| `backend/services/identifier_service.py` | Kennung erstellen und Format prüfen; noch nicht in die Dokumentverarbeitung eingebunden |
| `backend/services/document_router.py` | Leitet PDF, DOCX, PPTX und TXT an den jeweiligen Dienst weiter |
| `backend/services/pdf_service.py` | PDF wird neu geschrieben und erhält Metadaten; kein sichtbarer Schutz |
| `backend/services/word_service.py` | DOCX erhält einen Hinweis in der Fußzeile; Schutzstufen und Formatierung sind noch nicht vereinheitlicht |
| `backend/services/powerpoint_service.py` | PPTX erhält einen Hinweis pro Folie; Basistest vorhanden, Fehlerfälle noch offen |
| `backend/services/txt_service.py` | Liefert gültige Bytes zurück, fügt aber noch keine Kennzeichnung ein |
| `backend/services/excel_service.py`, `backend/services/ppt_service.py` | Platzhalter; nicht über den Upload-Router freigeschaltet |
| `backend/services/protection_service.py` | Experimenteller Stand mit Import-Ausgaben; noch nicht in die Verarbeitung eingebunden |
| `backend/services/ocr_service.py` | Separater OCR-Prototyp, nicht in die Haupt-API eingebunden |
| `backend/utils/file_storage.py`, `backend/utils/cleanup.py` | Unfertig; `file_storage.py` hat noch einen Pylance-Fehler (`Path` nicht definiert). Derzeit nicht benötigt, weil die Verarbeitung im Arbeitsspeicher erfolgt |

### Was wurde angepasst?

- Die Upload-Prüfung verwendet jetzt dieselbe zentrale Konfiguration wie der Router. Das
  10-MB-Limit wird in Bytes geprüft; Groß-/Kleinschreibung der Dateiendung ist egal.
- Der Router und die API verwenden Paket-Imports statt zur Laufzeit `sys.path` zu verändern.
- Der Upload wird höchstens bis zum Größenlimit plus einem Byte eingelesen.
- Der PPTX-Parser verwendet die gültigen `python-pptx`-Attribute und Argumente für Textfelder.
- Die TXT-Verarbeitung gibt Bytes statt fehlerhafter Zeichenketten zurück.
- Nicht fertige Excel- und alte Office-Formate werden nicht als erfolgreich verarbeitet
  ausgegeben.
- Laufzeitabhängigkeiten der vorhandenen Python-Module sind in `requirements.txt` aufgeführt.

### Lokal starten

```powershell
python -m pip install -r requirements.txt
python -m uvicorn backend.main:app --reload
```

`POST /document/process` erwartet eine Multipart-Datei unter `file` und eine Schutzstufe
`easy` oder `hard` unter `stufe`. Unterstützt sind PDF, DOCX, PPTX und TXT; Dateien dürfen
maximal 10 MB groß sein. OCR benötigt zusätzlich die nativen Programme Tesseract und
Poppler, ist aber noch nicht Teil dieses Upload-Endpunkts.

### Nächste Schritte

Die passenden TODO-Hinweise stehen direkt in den betroffenen Python-Dateien. Die empfohlene
Reihenfolge:

1. Die vorhandenen Format- und Größenlimit-Tests um beschädigte und passwortgeschützte
   Dateien sowie einen HTTP-End-to-End-Test ergänzen.
2. Festlegen und testen, was `easy` und `hard` in jedem Dateiformat genau bedeuten. Eine
   sichtbare Kennung ist nur ein Hinweis und verhindert keine KI-Verarbeitung.
3. Excel-Verarbeitung implementieren, bevor `.xlsx` wieder freigeschaltet wird; danach
   entscheiden, ob die veralteten Formate `.doc`, `.xls` und `.ppt` unterstützt werden.
4. OCR in die Haupt-API integrieren oder als separaten Dienst dokumentieren; danach
   temporäre Speicherung und Bereinigung nur dann ergänzen, wenn sie benötigt werden.

Die aktuell vorhandenen Tests laufen mit:

```powershell
python -m unittest discover -s tests
```
