"""Tests für erlaubte Uploads und die Grenzen der Datei-Validierung."""

import unittest

from backend.config import MAX_FILE_SIZE_BYTES
from backend.utils.file_validation import validate_upload


class ValidateUploadTests(unittest.TestCase):
    """Prüft Dateiendung, leere Inhalte und das konfigurierte Größenlimit."""

    def test_accepts_supported_extension_case_insensitively(self) -> None:
        self.assertTrue(validate_upload("referat.PDF", b"pdf bytes"))

    def test_accepts_file_at_size_limit(self) -> None:
        self.assertTrue(validate_upload("referat.txt", b"x" * MAX_FILE_SIZE_BYTES))

    def test_rejects_empty_file(self) -> None:
        with self.assertRaisesRegex(ValueError, "leer"):
            validate_upload("referat.pdf", b"")

    def test_rejects_file_over_size_limit(self) -> None:
        with self.assertRaisesRegex(ValueError, "10 MB"):
            validate_upload("referat.pdf", b"x" * (MAX_FILE_SIZE_BYTES + 1))

    def test_rejects_unsupported_extension(self) -> None:
        with self.assertRaisesRegex(ValueError, "nicht unterstützt"):
            validate_upload("referat.xlsx", b"excel bytes")


if __name__ == "__main__":
    unittest.main()
