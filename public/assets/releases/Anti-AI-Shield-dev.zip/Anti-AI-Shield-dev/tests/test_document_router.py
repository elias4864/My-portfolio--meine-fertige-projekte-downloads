"""Tests für Weiterleitung und Ausgabe der unterstützten Dokument-Services."""

from io import BytesIO
import unittest
from unittest.mock import patch

from docx import Document
from pptx import Presentation
from pypdf import PdfReader, PdfWriter

from backend.services.document_router import process_document
from backend.services.pdf_service import process as process_pdf
from backend.services.powerpoint_service import process as process_powerpoint
from backend.services.txt_service import process as process_text
from backend.services.word_service import process as process_word


class ProcessDocumentTests(unittest.TestCase):
    """Prüft Router-Auswahl und grundlegende Ergebnisse der Format-Services."""

    # TODO (NEU): Integrationstests für den HTTP-Endpunkt und beschädigte Office/PDF-Dateien ergänzen.
    def test_dispatches_valid_document(self) -> None:
        with patch(
            "backend.services.document_router.pdf_service.process",
            return_value=(b"processed", "processed.pdf"),
        ) as process_pdf:
            result = process_document("report.PDF", b"pdf bytes", "easy")

        self.assertEqual(result, (b"processed", "processed.pdf"))
        process_pdf.assert_called_once_with(b"pdf bytes", "easy")

    def test_rejects_unknown_protection_level(self) -> None:
        with self.assertRaisesRegex(ValueError, "Ungültige Schutzstufe"):
            process_document("report.txt", b"text", "unknown")

    def test_text_service_returns_bytes_and_filename(self) -> None:
        self.assertEqual(
            process_text(b"example", "easy"),
            (b"example", "verarbeitetes_dokument.txt"),
        )

    def test_pdf_service_returns_readable_pdf(self) -> None:
        source = BytesIO()
        writer = PdfWriter()
        writer.add_blank_page(width=100, height=100)
        writer.write(source)

        result, filename = process_pdf(source.getvalue(), "easy")

        self.assertEqual(filename, "geschuetzt_stufe_easy.pdf")
        self.assertEqual(len(PdfReader(BytesIO(result)).pages), 1)

    def test_word_service_adds_footer(self) -> None:
        source = BytesIO()
        document = Document()
        document.add_paragraph("Testinhalt")
        document.save(source)

        result, _ = process_word(source.getvalue(), "hard")
        processed = Document(BytesIO(result))

        self.assertIn("Stufe: Hoch", processed.sections[0].footer.paragraphs[0].text)

    def test_powerpoint_service_adds_a_marking_to_each_slide(self) -> None:
        source = BytesIO()
        presentation = Presentation()
        presentation.slides.add_slide(presentation.slide_layouts[6])
        presentation.save(source)

        result, filename = process_powerpoint(source.getvalue(), "hard")
        processed = Presentation(BytesIO(result))

        self.assertEqual(filename, "protected_praesentation.pptx")
        self.assertEqual(len(processed.slides), 1)
        self.assertTrue(
            any(
                "[HIGH]" in shape.text
                for shape in processed.slides[0].shapes
                if shape.has_text_frame
            )
        )


if __name__ == "__main__":
    unittest.main()
