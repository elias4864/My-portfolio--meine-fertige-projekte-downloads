"""Gemeinsame Einstellungen für Upload-Prüfung und Dokumentverarbeitung."""

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".pptx", ".txt"}
MAX_FILE_SIZE_MB = 10
MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024
PROTECTION_LEVELS = {"easy", "hard"}
