"""Startet die FastAPI-Anwendung und registriert ihre Endpunkte."""

from fastapi import FastAPI

from backend.routes.process import router as process_router

app = FastAPI(title="KI-Lernschutz")
app.include_router(process_router)


@app.get("/health")
def health() -> dict[str, str]:
    """Gibt den Status der laufenden API zurück."""
    return {"status": "ok"}
