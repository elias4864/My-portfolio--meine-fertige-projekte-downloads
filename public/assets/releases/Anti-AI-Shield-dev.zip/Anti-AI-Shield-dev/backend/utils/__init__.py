import importlib.util
import subprocess
import sys


def prepare_packages(packages: dict[str, str]):
    """
      Prüft, ob Pakete installiert sind, und installiert sie bei Bedarf.

      Args:
          packages: Dictionary mit {'import_name': 'pip_package_name'}
                    Beispiel: {'cv2': 'opencv-python', 'pandas': 'pandas'}
      """
    for import_name, pip_name in packages.items():

        if importlib.util.find_spec(import_name) is None:
            print(f"Installiere die  fehlendes Pakete/Libaries: {pip_name}...")
            try:
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", pip_name]
                )
                print(f"Erfolgreich installiert: {pip_name}")
            except subprocess.CalledProcessError as e:
                print(f"Fehler bei der Installation von {pip_name}: {e}")
                sys.exit(1)
        else:
            print(f"Bereits vorhanden: {import_name}")


# Testbeispiel von Libaries die isntalliert werden
if __name__ == "__main__":
    required = {
        "requests": "requests",
        "bs4": "beautifulsoup4",  # Import-Name unterscheidet sich vom Pip-Namen
        "pandas": "pandas>=2.0.0",  # Versionsangabe ist ebenfalls möglich
    }
    prepare_packages(required)

    # Danach können die Pakete normal importiert werden
    import bs4
    import requests
