"""Prüft Dateiendung, Inhalt und Größenlimit eingehender Uploads."""

from pathlib import Path

from backend.config import ALLOWED_EXTENSIONS, MAX_FILE_SIZE_BYTES, MAX_FILE_SIZE_MB


def validate_upload(filename: str, file_bytes: bytes) -> bool:
    """Akzeptiert unterstützte, nicht leere Dateien bis zur konfigurierten Maximalgröße."""
    if not filename or not isinstance(filename, str):
        raise ValueError("Es wurde kein gültiger Dateiname angegeben.")
    if not isinstance(file_bytes, bytes) or not file_bytes:
        raise ValueError("Die Datei ist leer oder der Dateiinhalt ist ungültig.")
    if len(file_bytes) > MAX_FILE_SIZE_BYTES:
        raise ValueError(
            f"Die Datei ist zu groß. Die maximale Dateigröße beträgt {MAX_FILE_SIZE_MB} MB."
        )

    extension = Path(filename).suffix.lower()
    if extension not in ALLOWED_EXTENSIONS:
        allowed = ", ".join(sorted(ALLOWED_EXTENSIONS))
        raise ValueError(
            f"Die Dateiendung '{extension}' wird nicht unterstützt. Erlaubt sind: {allowed}."
        )

    # TODO (NEU): Dateiinhalte prüfen, damit Endung und tatsächliches Format übereinstimmen.
    return True
