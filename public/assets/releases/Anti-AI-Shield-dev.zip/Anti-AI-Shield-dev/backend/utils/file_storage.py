#Used Imports
import os
import pathlib
import tempfile



# TODO: [ ] Temporären Speicherort vorbereiten
# TODO (NEU): Erst bei tatsächlichem Speicherbedarf integrieren; dann Dateinamen bereinigen und Path importieren.


def process_temp_storage(filename:str,datei_bytes:bytes,stufe: str):
    """Verarbeitet eine Datei über temporäre Speicherorte(temp-Files)
    und
    """
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)


        # Downloaded File vorübergehend speichern

        input_file_path = temp_dir / filename
        with open(input_file_path, "wb") as f:
            f.write(datei_bytes)



        # TODO: [ ] Hochgeladene Dateien vorübergehend speichern


        print(f"Die hochgeladene Datei wurde temporären unter: {input_file_path}","gespeichert")

        #Dateipfade für Weiterverarbeitung bereitstellen

        output_filename = f"Protected_{filename}"
        output_file_path = temp_dir / output_filename

        print(f"[Temp-Storage] Pfade für Verarbeitung bereitgestellt.")




        # TODO: [ ] Verarbeitete Dateien vorübergehend speichern

        # 4. Verarbeitete Dateien vorübergehend speichern (Beispiel-Logik)
        # Datei für Hard-Mode in Schreibvorgang speichern in (Temp-Mode9
        # (In deinem echten Code würdest du hier deine docx/pdf-Verarbeitung aufrufen)
        processed_bytes = datei_bytes  # Platzhalter für das echte Ergebnis


        with open(output_file_path, "wb") as f_out:
            f_out.write(processed_bytes)

            # TODO: [ ] Dateien nach der Rückgabe zur Löschung freigeben

        print(f"[Temp-Storage] Verarbeitete Datei temporär gespeichert unter: {output_file_path}")

        # Die verarbeiteten Bytes zum Rückgabewert einlesen, bevor der Ordner gelöscht wird

        with open(output_file_path, "rb") as f_read:
            ergebnis_bytes = f_read.read()

            # 5. Dateien nach der Rückgabe zur Löschung freigeben
            # Sobald wir den 'with'-Block verlassen, greift Python automatisch
            # und gibt alle Ressourcen / den Temp-Ordner komplett frei.
            return ("Die Angegebebe Länge der Bytes ist"+ergebnis_bytes,"mit dem Output-Namen", output_filename)




# TODO: [ ] Dateipfade für die Verarbeitung bereitstellen


#File temporär in Storage-Speichern

if __name__ == "__main__":
    test_document = "elias.docx"
    test_bytes = b"Dies ist eine Testnachricht"

    try:
        loesungs_bytes, neuer_name = process_temp_storage(test_document, test_bytes, stufe="hoch")
        print(f"Erfolgreich! Neuer Name: {neuer_name}, Bytelänge: {len(loesungs_bytes)}")
    except Exception as e:
        print(f"Ein Fehler ist aufgetreten, der Path ist  nicht definiert: {e}")
