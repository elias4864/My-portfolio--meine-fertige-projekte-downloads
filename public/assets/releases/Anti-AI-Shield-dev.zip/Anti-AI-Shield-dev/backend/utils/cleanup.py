# TODO: Erst entscheiden, ob Dateien ueberhaupt auf der Festplatte gespeichert werden.
# Wenn alles im Arbeitsspeicher verarbeitet wird, ist weniger Bereinigung noetig.
# TODO (NEU): Bis dahin keine allgemeine Bereinigung einbauen; sie darf nur eigene Temp-Dateien entfernen.

# TODO: Falls temporaere Dateien entstehen: nur die eigenen Projektdateien loeschen.
# Bereinigung auch dann planen, wenn die Verarbeitung mit einem Fehler endet.