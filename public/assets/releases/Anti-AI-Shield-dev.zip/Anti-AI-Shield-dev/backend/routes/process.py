"""Stellt den Upload-Endpunkt zum Verarbeiten und Herunterladen von Dateien bereit."""

from io import BytesIO

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import StreamingResponse

from backend.config import MAX_FILE_SIZE_BYTES
from backend.services.document_router import process_document

router = APIRouter()


@router.post("/document/process")
async def process_document_route(
    file: UploadFile = File(...),
    stufe: str = Form(...),
) -> StreamingResponse:
    """Prüft Upload und Schutzstufe und liefert das Ergebnis als Download zurück."""
    if not file.filename:
        raise HTTPException(status_code=400, detail="Bitte eine Datei auswählen.")

    # TODO (NEU): Ergänze API-Tests für leere, zu große und erfolgreiche Uploads.
    file_bytes = await file.read(MAX_FILE_SIZE_BYTES + 1)
    try:
        result_bytes, output_filename = process_document(
            file.filename,
            file_bytes,
            stufe,
        )
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error

    return StreamingResponse(
        BytesIO(result_bytes),
        media_type="application/octet-stream",
        # TODO (NEU): Dateinamen für Download-Header sicher kodieren, auch bei Sonderzeichen.
        headers={"Content-Disposition": f'attachment; filename="{output_filename}"'},
    )
