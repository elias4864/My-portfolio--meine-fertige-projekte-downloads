"""Liest PDF-Dateien im Speicher ein und schreibt sie mit Titel-Metadaten neu."""

import io
from pypdf import PdfReader, PdfWriter


def process(inhalt: bytes, stufe: str):
    """Einheitlicher Einstiegspunkt für PDF-Dateien im Dokument-Router."""
    return process_pdf(inhalt, stufe)


def process_pdf(inhalt: bytes, stufe: str):
    """Kopiert PDF-Seiten, setzt Titel-Metadaten und gibt Bytes sowie Dateiname zurück.

    Die Schutzstufe wird aktuell nur im Titel und im Ausgabedateinamen vermerkt.
    """
    try:
        # 1. PDF aus Bytes im Arbeitsspeicher öffnen (ohne temporäre Datei auf Festplatte)
        input_stream = io.BytesIO(inhalt)
        reader = PdfReader(input_stream)
        writer = PdfWriter()

        # Prüfen, ob die PDF beschädigt ist, leer ist  oder Seiten hat
        if len(reader.pages) == 0:
            raise ValueError("Die PDF-Datei enthält keine Seiten oder ist leer.")

        # 2. Seiten nacheinander bearbeiten
        # (Hier im Beispiel kopieren wir vorerst alle Seiten durch)
        for page in reader.pages:
            # TODO (NEU): Nach Festlegung der Schutzstufen eine sichtbare Markierung ergänzen und testen.
            # TODO: Hier kannst du je nach 'stufe' Anpassungen an der Seite vornehmen
            # z.B. Wasserzeichen einfügen oder Metadaten setzen
            writer.add_page(page)

        # 3. Kennung / Metadaten je nach Stufe anpassen (Beispiel)
        writer.add_metadata({
            "/Title": f"Anti-AI-Shield Protected (Stufe {stufe})"
        })

        # 4. Die bearbeitete PDF wieder in Bytes umwandeln
        output_stream = io.BytesIO()
        writer.write(output_stream)
        ergebnis_bytes = output_stream.getvalue()

        # 5. Neuen Dateinamen generieren
        neuer_dateiname = f"geschuetzt_stufe_{stufe}.pdf"
        return ergebnis_bytes, neuer_dateiname



    except Exception as e:
        # Fehler bei kaputten oder passwortgeschützten PDFs abfangen
        raise ValueError(f"Fehler beim Verarbeiten der PDF-Datei: {e}") from e
