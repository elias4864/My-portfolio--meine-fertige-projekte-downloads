"""Stellt die einfache Verarbeitungsschnittstelle für TXT-Dateien bereit."""

def process(inhalt: bytes, stufe: str):
    """Gibt Text-Bytes unverändert zurück, bis ein Markierungsformat festgelegt ist."""
    # TODO (NEU): Markierung und Textkodierung ergänzen, sobald das TXT-Format festgelegt wurde.
    return inhalt, "verarbeitetes_dokument.txt"
