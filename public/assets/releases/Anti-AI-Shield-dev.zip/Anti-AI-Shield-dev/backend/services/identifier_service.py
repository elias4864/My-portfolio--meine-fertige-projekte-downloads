import random


# Die Kennung hat 10 Zeichen: KLS-XXXXXX
# Die sechs Zeichen bestehen aus zufälligen Buchstaben (A-Z) oder Zahlen (0-9).
def create_identifier():
    # TODO (NEU): Bei dauerhaft eindeutigen Kennungen Vergabe speichern und Kollisionen prüfen.
    kennungsn = "KLS-"
    zeichen = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    zufall = random.choices(zeichen, k=6)
    erkennung = kennungsn + "".join(zufall)

    return erkennung


# Prüft das Format der Kennung, nicht eine kryptografische Prüfziffer.
def is_valid_identifier(identifier):
    if not isinstance(identifier, str):
        return False

    # Drei Bedingungen: richtiger Anfang, insgesamt 10 Zeichen,
    # und die letzten sechs Zeichen sind Buchstaben oder Zahlen.
    if (
        identifier.startswith("KLS-")
        and len(identifier) == 10
        and all(
            zeichen in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            for zeichen in identifier[4:]
        )
    ):
        return True
    else:
        return False


# Nur beim direkten Start ausführen, nicht beim Import in andere Dateien.
if __name__ == "__main__":
    identifier = create_identifier()
    print(identifier)
    print(is_valid_identifier(identifier))
