"""Ergänzt DOCX-Dokumente im Speicher um einen Hinweis in der Fußzeile."""

import io
from docx import Document


def process(inhalt: bytes, stufe: str):
    """Setzt abhängig von der Stufe einen Hinweis in die Fußzeile und liefert DOCX-Bytes.

    Die Kennzeichnung ist ein sichtbarer Hinweis, kein technischer Kopierschutz.
    """
    try:
        docx_file = io.BytesIO(inhalt)
        doc = Document(docx_file)

        footer = doc.sections[0].footer
        footer_paragraph = footer.paragraphs[0]

        if len(footer.paragraphs) > 0:
            footer_paragraph = footer.paragraphs[0]
        else:
            footer_paragraph = footer.add_paragraph()

        # TODO (NEU): "easy" und "hard" mit der API-Spezifikation vereinheitlichen und beide Stufen testen.
        if stufe.lower() in {"hard", "hoch", "3"}:
            footer_paragraph.text = "Anti-AI-Shield: Dokument ist gegen unbefugtes Scraping geschützt (Stufe: Hoch)."
        elif stufe.lower() == "mittel" or stufe == "2":
            footer_paragraph.text = "Anti-AI-Shield geschützt (Stufe: Mittel)."
        else:
            footer_paragraph.text = "Anti-AI-Shield aktiv (Stufe: Basis)."





        output_io = io.BytesIO()
        doc.save(output_io)
        output_io.seek(0)

        ergebnis_bytes = output_io.getvalue()
        neuer_dateiname = "protected_dokument.docx"
        print(f"Protected-dokument Dateiname: {neuer_dateiname}")

        return ergebnis_bytes, neuer_dateiname

    except Exception as e:
        raise ValueError(f"Fehler bei der Verarbeitung der Word-Datei: {str(e)}")


    #Testing der Validierung  mit Beispiel Dateipfad
if __name__ == "__main__":
    dateipfad = "mein_test_dokument.docx"  # Ersetze dies mit dem echten Pfad zu deiner .docx-Datei

    try:
        with open(dateipfad, "rb") as f:
            datei_bytes = f.read()

        # Funktion mit Eingschränkter Stufe validieren
        ergebnis_bytes, neuer_name = process(datei_bytes, stufe="hoch")

        # Daetiname und Anzahl Bytes länge sowie erset 50 Bytes ausgegeben
        print(f"Dateiname: {neuer_name}")
        print(f"Anzahl Bytes (Dateilänge): {len(ergebnis_bytes)}")
        print(f"Erste 50 Bytes (Hex): {ergebnis_bytes[:50]}")

        # Datei  durch Lehrer als geschützte Datei spiechern==>Had Protection
        with open(neuer_name, "wb") as f_out:
            f_out.write(ergebnis_bytes)
        print(f"Datei erfolgreich als '{neuer_name}' gespeichert!")

        # Fußzeile zur Kontrolle prüfen
        check_doc = Document(io.BytesIO(ergebnis_bytes))
        verarbeitete_fusszeile = check_doc.sections[0].footer.paragraphs[0].text
        print(f"Inhalt der Fußzeile: {verarbeitete_fusszeile}")



      #Expection-handlung für Daetipfad des Testfiles
    except FileNotFoundError:
        print(f"Achtung: Die Testdatei '{dateipfad}' wurde nicht gefunden. Bitte erstelle oder benenne eine Word-Datei.")

    except ValueError as e:
        print(f"Fehler bei der Verarbeitung: {str(e)}")
