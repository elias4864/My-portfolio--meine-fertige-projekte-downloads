"""Validiert Dokumente und leitet sie an den passenden Format-Service weiter."""

from backend.config import PROTECTION_LEVELS
from backend.services import pdf_service, powerpoint_service, txt_service, word_service
from backend.utils.file_validation import validate_upload


def process_document(filename: str, file_bytes: bytes, level: str) -> tuple[bytes, str]:
    """Prüft Datei und Schutzstufe und gibt Ergebnis-Bytes samt Dateiname zurück."""
    validate_upload(filename, file_bytes)

    # TODO (NEU): Kennung erzeugen und an die Format-Services geben, sobald das Markierungsformat feststeht.
    if level not in PROTECTION_LEVELS:
        allowed = ", ".join(sorted(PROTECTION_LEVELS))
        raise ValueError(f"Ungültige Schutzstufe '{level}'. Erlaubt sind: {allowed}.")

    extension = filename.rsplit(".", maxsplit=1)[-1].lower()
    if extension == "pdf":
        processor = pdf_service.process
    elif extension == "docx":
        processor = word_service.process
    elif extension == "pptx":
        processor = powerpoint_service.process
    elif extension == "txt":
        processor = txt_service.process
    else:
        raise ValueError(f"Der Dateityp '.{extension}' wird nicht unterstützt.")

    return processor(file_bytes, level)
