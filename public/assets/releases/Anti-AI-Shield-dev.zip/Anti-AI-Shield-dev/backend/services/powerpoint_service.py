"""Fügt Schutzstufen-Hinweise in PowerPoint-Folien ein."""

import io
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor


def process(inhalt: bytes, stufe: str):
    """Fügt jeder PPTX-Folie einen farbigen Hinweis hinzu und liefert das Ergebnis zurück.

    Die Hinweise sind sichtbare Markierungen, kein technischer Schutz vor Scraping.
    """
    try:
        # 1. PPTX-Bytes mit io.BytesIO in ein für python-pptx lesbares Format laden
        pptx_file = io.BytesIO(inhalt)
        prs = Presentation(pptx_file)

        # 2. Präsentation öffnen und testen, ob Folien vorhanden sind
        if not prs.slides:
            raise ValueError("Die PowerPoint-Präsentation enthält keine Folien und kann nicht verarbeitet werden.")
        # 3. Schutzstufe auswerten
        stufe_str = str(stufe).lower()

        # TODO (NEU): Schutzstufen mit Word/PDF vereinheitlichen und Foliengrößen für die Hinweisposition berücksichtigen.
        # 4. Kennung auf jeder Folie einfügen (Position und Schriftgröße definiert)
        for slide in prs.slides:
            # Unterschiedliche Protection Stufen-Implementierung (Easy vs. Hard-Mode)
            if stufe_str in ["hard", "hoch", "3"]:
                notice_text = "Anti-AI-Shield [HIGH]: Scraping & automatisches Auslesen strengstens untersagt."
                font_color = RGBColor(200, 0, 0)  # Auffälliges Rot für hohe Stufe
            elif stufe_str in ["mittel", "2"]:
                notice_text = "Anti-AI-Shield [MEDIUM]: Urheberrechtlich geschützter Inhalt."
                font_color = RGBColor(100, 100, 100)  # Dezentes Grau
            else:
                notice_text = "Anti-AI-Shield [BASIC]: Hinweis aktiv."
                font_color = RGBColor(150, 150, 150)  # Hellgrau

            # Textbox unten als Fußzeile auf der Folie platzieren
            left = Inches(1.0)
            top = Inches(7.0)
            width = Inches(8.0)
            height = Inches(0.5)
            textbox = slide.shapes.add_textbox(left, top, width, height)
            tf = textbox.text_frame
            p = tf.paragraphs[0]
            p.text = notice_text
            p.font.size = Pt(10)
            p.font.color.rgb = font_color

        # 5. Bearbeitete Präsentation wieder in Bytes umwandeln (In-Memory) HTML==>Bytes
        output_io = io.BytesIO()
        prs.save(output_io)
        output_io.seek(0)

        ergebnis_bytes = output_io.getvalue()
        neuer_dateiname = "protected_praesentation.pptx"

        return ergebnis_bytes, neuer_dateiname

    except Exception as e:
        raise ValueError(f"Fehler bei der Verarbeitung der PowerPoint-Datei: {e}") from e