#Import für identifizierungs nummer
from identifier_service import create_identifier
# TODO (NEU): Schutzstufen zentral aus backend.config beziehen und Import-Ausgaben entfernen.
# TODO: Festlegen, welche Werte fuer die Schutzstufe erlaubt sind.
# Beispiel: "easy" und "hard". Was soll bei einem anderen Wert passieren?
# Liste mit den Akzeptierten Level
allowed_levels = ["easy", "hard"]

#Funktion zum prüfen der Level
def is_valid_level(level):
    #wenn Level in der Liste Allowed Level ist print True sosnt gib falsch zurück
    if level  in allowed_levels:
        return True
    else:
        return False

# TODO: Die Bedeutung der Stufen gemeinsam festlegen, bevor ihr sie programmiert.
# Beispielidee (noch kein fertiger Schutz): easy = Kennung in der Fusszeile;
# hard = Fusszeile plus deutlich sichtbarer Hinweis.

#Dixonar mit den Verschiedenen  Levels
protection_levels ={
    "easy":"Einfache Erkennung",
    "hard":"Erweiterte Erkennung",
}

#Einfacher dixonar auswählen
print(protection_levels["easy"])

#Schwierige ausgabe
selectet_level ="hard"
print(protection_levels[selectet_level])
def valid_selected_level(selected_level):
    return selected_level in protection_levels

# TODO: Eine kleine Funktion planen, die Stufe und Kennung entgegennimmt.
# Beispiel: create_marking("KLS-A1B2C3", "Biologie") -> lesbarer Kennzeichnungstext

def create_marking(identifier, subject):

        # Fach auf die ersten 3 Buchstaben kürzen und gross schreiben
        subject_code = subject.upper()[:3]

        # Kennzeichnung zusammensetzen
        marking = identifier + "-" + subject_code

        # Ergebnis zurückgeben
        return marking


identifier = create_identifier()

marking = create_marking(identifier, "Biologie")

print(marking)